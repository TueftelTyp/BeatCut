$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "Node.js wurde nicht gefunden."
    Write-Host "Alternativ: python -m http.server 8080"
    Read-Host "Enter zum Beenden"
    exit 1
}

node .\server.cjs
