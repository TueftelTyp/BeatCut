@echo off
setlocal
cd /d "%~dp0"

echo.
echo ==========================================
echo  BeatCut Studio - Webversion
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
    echo Node.js wurde nicht gefunden.
    echo.
    echo Alternative: Wenn Python installiert ist, starte:
    echo   python -m http.server 8080
    echo.
    pause
    exit /b 1
)

node server.cjs
