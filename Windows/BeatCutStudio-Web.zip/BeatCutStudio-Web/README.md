# BeatCut Studio – Webversion

Diese Variante läuft direkt in einem normalen Chromium-Browser und verwendet **kein Electron und kein WebView2**.

## Empfohlen

- Microsoft Edge oder Google Chrome in aktueller Version
- Projekt über einen lokalen Webserver starten, **nicht** per Doppelklick als `file://`

## Schnellstart unter Windows

1. ZIP entpacken.
2. `start-web.bat` doppelklicken.
3. Der Browser öffnet `http://127.0.0.1:8080` automatisch.

Voraussetzung für das Startskript: Node.js. Es werden keine npm-Pakete benötigt.

Alternativ mit Python:

```text
python -m http.server 8080
```

Danach im Browser `http://127.0.0.1:8080` öffnen.

## MP4-Export

Der MP4-Export läuft in dieser Webversion wieder direkt im Browser und verwendet FFmpeg.wasm. Beim ersten MP4-Export wird FFmpeg aus dem Internet geladen. WebM benötigt diesen zusätzlichen Schritt nicht.

Die Anwendung erzeugt MP4 mit H.264/YUV420P, AAC, konstanter Framerate, neu gesetzten Zeitstempeln, `faststart` und einer festen Projektdauer. Dadurch werden fehlerhafte Laufzeitangaben in Social-Media-Plattformen reduziert.

## Externe Ressourcen

Aktuell werden weiterhin einige Ressourcen aus dem Internet geladen:

- JSZip
- Google Fonts
- FFmpeg.wasm

Für vollständig offlinefähigen Betrieb müssten diese Ressourcen in einer späteren Version lokal mitgeliefert werden.

## Hinweis zur Leistung

Die Vorschau und der Export sind rechenintensiv. Für 1080x1920-Projekte mit mehreren Videos und Effekten ist ein aktueller Chromium-Browser mit Hardwarebeschleunigung empfohlen.
