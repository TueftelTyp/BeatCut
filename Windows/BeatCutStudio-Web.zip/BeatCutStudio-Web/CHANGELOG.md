# BeatCut Studio Web – Stand dieses Pakets

- reine Browser-Version ohne Electron/WebView2
- Medien- und Musikimport
- Medien und Musik per Drag & Drop in die Timeline
- Mehrspur-Timeline
- Originalton als einzeln auswählbare Abschnitte
- Originalton-Abschnitte einzeln deaktivierbar/löschbar
- Audio-FX für Musik, komplette Originaltonspur oder einzelnen Originalton-Abschnitt
- Audio-FX auf mehrere markierte Originalton-Abschnitte
- Fade-In/Fade-Out und Lautstärke für Originalton
- SmartCut, BPM-/Beat-Analyse und Szenenanalyse
- Texte, Videoeffekte und Übergänge
- Spur-Auswahl über den Spurnamen
- Rückgängig / Wiederherstellen
- Kopieren markierter Timeline-Elemente an den Playhead
- Videolängen-Limit mit aktualisierter Limit-Linie
- WebM-Export
- MP4-Normalisierung über FFmpeg.wasm mit CFR, H.264/YUV420P, AAC, Faststart und fester Projektdauer

## Hinweis zum MP4-Export

Der Browser muss FFmpeg.wasm beim ersten MP4-Export aus dem Internet laden können. Ein kompletter End-to-End-Export mit deinen konkreten Medien ist in diesem Paket nicht vorab ausführbar, weil die Quelldateien erst lokal im Browser ausgewählt werden.
