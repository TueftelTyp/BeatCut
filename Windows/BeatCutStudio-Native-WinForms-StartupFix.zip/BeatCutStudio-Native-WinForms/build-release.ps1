$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

dotnet restore ".\BeatCutStudio.sln"
if ($LASTEXITCODE -ne 0) { throw "Restore fehlgeschlagen." }

$publish = Join-Path $root "publish\win-x64"
if (Test-Path $publish) { Remove-Item $publish -Recurse -Force }

dotnet publish ".\BeatCutStudio\BeatCutStudio.csproj" `
    -c Release `
    -r win-x64 `
    --self-contained true `
    -p:PublishSingleFile=false `
    -o $publish

if ($LASTEXITCODE -ne 0) { throw "Publish fehlgeschlagen." }
Write-Host "Fertig: $publish"
