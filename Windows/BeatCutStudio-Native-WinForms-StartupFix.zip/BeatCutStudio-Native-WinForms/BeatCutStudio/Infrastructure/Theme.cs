namespace BeatCutStudio.Infrastructure;

public static class Theme
{
    public static readonly Color Background = Color.FromArgb(9, 10, 14);
    public static readonly Color Panel = Color.FromArgb(17, 19, 25);
    public static readonly Color Panel2 = Color.FromArgb(24, 27, 35);
    public static readonly Color Panel3 = Color.FromArgb(32, 36, 47);
    public static readonly Color Border = Color.FromArgb(43, 48, 60);
    public static readonly Color Text = Color.FromArgb(247, 247, 250);
    public static readonly Color Muted = Color.FromArgb(146, 152, 170);
    public static readonly Color Accent = Color.FromArgb(115, 87, 255);
    public static readonly Color Danger = Color.FromArgb(255, 91, 116);
    public static readonly Color Green = Color.FromArgb(49, 200, 135);
    public static readonly Color Blue = Color.FromArgb(53, 168, 216);

    public static void Apply(Control root)
    {
        root.BackColor = Background;
        root.ForeColor = Text;
        ApplyRecursive(root);
    }

    private static void ApplyRecursive(Control control)
    {
        foreach (Control child in control.Controls)
        {
            child.ForeColor = Text;

            switch (child)
            {
                case Button button:
                    button.FlatStyle = FlatStyle.Flat;
                    button.FlatAppearance.BorderColor = Border;
                    button.BackColor = Panel2;
                    break;
                case TextBoxBase:
                case NumericUpDown:
                case ComboBox:
                    child.BackColor = Color.FromArgb(12, 14, 19);
                    break;
                case ListView:
                case TreeView:
                case PropertyGrid:
                    child.BackColor = Panel;
                    break;
                case System.Windows.Forms.Panel:
                case GroupBox:
                    child.BackColor = Panel;
                    break;
            }

            ApplyRecursive(child);
        }
    }
}
