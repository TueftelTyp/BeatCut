using System.Text.Json;
using System.Text.Json.Serialization;
using BeatCutStudio.Models;

namespace BeatCutStudio.Services;

public sealed class ProjectService
{
    private readonly JsonSerializerOptions _options = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public async Task SaveAsync(BeatCutProject project, string path, CancellationToken cancellationToken = default)
    {
        await using var stream = File.Create(path);
        await JsonSerializer.SerializeAsync(stream, project, _options, cancellationToken);
    }

    public async Task<BeatCutProject> LoadAsync(string path, CancellationToken cancellationToken = default)
    {
        await using var stream = File.OpenRead(path);
        var project = await JsonSerializer.DeserializeAsync<BeatCutProject>(stream, _options, cancellationToken);
        return project ?? throw new InvalidDataException("Die Projektdatei ist leer oder ungültig.");
    }

    public string Serialize(BeatCutProject project) => JsonSerializer.Serialize(project, _options);

    public BeatCutProject Deserialize(string json) =>
        JsonSerializer.Deserialize<BeatCutProject>(json, _options)
        ?? BeatCutProject.CreateDefault();
}
