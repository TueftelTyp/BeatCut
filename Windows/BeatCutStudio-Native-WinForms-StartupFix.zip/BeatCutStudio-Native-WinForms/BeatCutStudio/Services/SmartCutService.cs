using BeatCutStudio.Models;

namespace BeatCutStudio.Services;

public sealed class SmartCutService
{
    public void Generate(BeatCutProject project, SmartCutSettings settings)
    {
        var videoTrack = project.Tracks.FirstOrDefault(t => t.Type == TrackType.Video)
            ?? throw new InvalidOperationException("Keine Videospur vorhanden.");

        var candidates = project.Assets
            .Where(a => a.Type is MediaAssetType.Video or MediaAssetType.Image)
            .ToList();

        if (candidates.Count == 0)
            throw new InvalidOperationException("Für SmartCut sind noch keine Bilder oder Videos importiert.");

        if (settings.ReplaceExistingVideoClips)
            project.Clips.RemoveAll(c => c.TrackId == videoTrack.Id);

        project.Bpm = Math.Clamp(settings.Bpm, 40, 240);
        var secondsPerBeat = 60.0 / project.Bpm;
        var baseDuration = Math.Clamp(secondsPerBeat * Math.Max(1, settings.BeatsPerClip), 0.35, 8.0);

        var styleMultiplier = settings.Style switch
        {
            "Energetic" => 0.55,
            "Dynamic" => 0.72,
            "Cinematic" => 1.35,
            "Smooth" => 1.55,
            "Minimal" => 1.75,
            "Glitch / Tech" => 0.65,
            _ => 1.0
        };

        var clipDuration = Math.Clamp(baseDuration * styleMultiplier, 0.35, 8.0);
        var target = Math.Max(1, settings.TargetDuration);
        var random = new Random();
        var bag = candidates.OrderBy(_ => random.Next()).ToList();
        var bagIndex = 0;
        var time = 0.0;

        while (time < target - 0.01)
        {
            if (bagIndex >= bag.Count)
            {
                bag = candidates.OrderBy(_ => random.Next()).ToList();
                bagIndex = 0;
            }

            var asset = bag[bagIndex++];
            var duration = Math.Min(clipDuration, target - time);
            var sourceStart = 0.0;

            if (asset.Type == MediaAssetType.Video && asset.Duration > duration + 0.25)
            {
                sourceStart = random.NextDouble() * Math.Max(0, asset.Duration - duration - 0.1);
            }

            project.Clips.Add(new TimelineClip
            {
                TrackId = videoTrack.Id,
                AssetId = asset.Id,
                Start = time,
                Duration = duration,
                SourceStart = sourceStart
            });

            time += duration;
        }
    }
}
