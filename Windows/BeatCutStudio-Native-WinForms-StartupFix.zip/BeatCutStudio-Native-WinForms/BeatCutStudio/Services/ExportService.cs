using System.Globalization;
using BeatCutStudio.Models;

namespace BeatCutStudio.Services;

public sealed class ExportService
{
    private readonly FfmpegLocator _locator;

    public ExportService(FfmpegLocator locator)
    {
        _locator = locator;
    }

    public async Task ExportAsync(
        BeatCutProject project,
        ExportSettings settings,
        IProgress<int>? progress = null,
        IProgress<string>? log = null,
        CancellationToken cancellationToken = default)
    {
        _locator.Refresh();
        if (!_locator.IsAvailable || _locator.FfmpegPath is null)
            throw new InvalidOperationException("FFmpeg/FFprobe wurde nicht gefunden. Lege ffmpeg.exe und ffprobe.exe unter Tools\\FFmpeg ab oder installiere FFmpeg in PATH.");

        var videoTrack = project.Tracks.FirstOrDefault(t => t.Type == TrackType.Video);
        if (videoTrack is null)
            throw new InvalidOperationException("Keine Videospur vorhanden.");

        var clips = project.Clips
            .Where(c => c.TrackId == videoTrack.Id)
            .OrderBy(c => c.Start)
            .ToList();

        if (clips.Count == 0)
            throw new InvalidOperationException("Die Videospur enthält keine Clips.");

        var tempRoot = Path.Combine(Path.GetTempPath(), "BeatCutStudio", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(tempRoot);

        try
        {
            var segments = new List<string>();
            var cursor = 0.0;
            var totalWork = clips.Count + 3;
            var work = 0;

            foreach (var clip in clips)
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (clip.Start > cursor + 0.01)
                {
                    var gapDuration = clip.Start - cursor;
                    var gapPath = Path.Combine(tempRoot, $"segment_{segments.Count:0000}.mp4");
                    await RenderGapAsync(gapPath, gapDuration, settings, log, cancellationToken);
                    segments.Add(gapPath);
                }

                var asset = project.FindAsset(clip.AssetId)
                    ?? throw new InvalidOperationException("Ein Timeline-Clip verweist auf ein fehlendes Medium.");

                var segmentPath = Path.Combine(tempRoot, $"segment_{segments.Count:0000}.mp4");
                await RenderClipAsync(asset, clip, segmentPath, settings, log, cancellationToken);
                segments.Add(segmentPath);

                cursor = Math.Max(cursor, clip.End);
                progress?.Report((int)Math.Round(++work * 100.0 / totalWork));
            }

            var concatFile = Path.Combine(tempRoot, "concat.txt");
            await File.WriteAllLinesAsync(concatFile,
                segments.Select(path => $"file '{path.Replace("'", "'\\''")}'"), cancellationToken);

            var basePath = Path.Combine(tempRoot, "base.mp4");
            await ProcessRunner.RunAsync(_locator.FfmpegPath,
            [
                "-y",
                "-f", "concat",
                "-safe", "0",
                "-i", concatFile,
                "-c", "copy",
                "-movflags", "+faststart",
                basePath
            ], log, cancellationToken);
            progress?.Report((int)Math.Round(++work * 100.0 / totalWork));

            var musicTrack = project.Tracks.FirstOrDefault(t => t.Type == TrackType.Music);
            var musicClips = settings.IncludeMusic && musicTrack is not null
                ? project.Clips.Where(c => c.TrackId == musicTrack.Id).OrderBy(c => c.Start).ToList()
                : [];

            if (musicClips.Count == 0)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(settings.OutputPath)!);
                File.Copy(basePath, settings.OutputPath, true);
            }
            else
            {
                await MixMusicAsync(project, basePath, musicClips, settings.OutputPath, log, cancellationToken);
            }

            progress?.Report(100);
        }
        finally
        {
            try { Directory.Delete(tempRoot, true); } catch { }
        }
    }

    private async Task RenderGapAsync(
        string outputPath,
        double duration,
        ExportSettings settings,
        IProgress<string>? log,
        CancellationToken cancellationToken)
    {
        var d = F(duration);
        await ProcessRunner.RunAsync(_locator.FfmpegPath!,
        [
            "-y",
            "-f", "lavfi",
            "-i", $"color=c=black:s={settings.Width}x{settings.Height}:r={settings.Fps}:d={d}",
            "-f", "lavfi",
            "-i", "anullsrc=channel_layout=stereo:sample_rate=48000",
            "-t", d,
            "-c:v", "libx264",
            "-preset", settings.Preset,
            "-crf", settings.Crf.ToString(CultureInfo.InvariantCulture),
            "-pix_fmt", "yuv420p",
            "-r", settings.Fps.ToString(CultureInfo.InvariantCulture),
            "-c:a", "aac",
            "-ar", "48000",
            "-ac", "2",
            "-shortest",
            outputPath
        ], log, cancellationToken);
    }

    private async Task RenderClipAsync(
        MediaAsset asset,
        TimelineClip clip,
        string outputPath,
        ExportSettings settings,
        IProgress<string>? log,
        CancellationToken cancellationToken)
    {
        var duration = F(clip.Duration);
        var scale = $"scale={settings.Width}:{settings.Height}:force_original_aspect_ratio=decrease,pad={settings.Width}:{settings.Height}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,fps={settings.Fps},format=yuv420p";

        if (asset.Type == MediaAssetType.Image)
        {
            await ProcessRunner.RunAsync(_locator.FfmpegPath!,
            [
                "-y",
                "-loop", "1",
                "-t", duration,
                "-i", asset.FilePath,
                "-f", "lavfi",
                "-i", "anullsrc=channel_layout=stereo:sample_rate=48000",
                "-vf", scale,
                "-t", duration,
                "-c:v", "libx264",
                "-preset", settings.Preset,
                "-crf", settings.Crf.ToString(CultureInfo.InvariantCulture),
                "-pix_fmt", "yuv420p",
                "-r", settings.Fps.ToString(CultureInfo.InvariantCulture),
                "-c:a", "aac",
                "-ar", "48000",
                "-ac", "2",
                "-shortest",
                outputPath
            ], log, cancellationToken);
            return;
        }

        var volume = clip.Muted ? 0 : Math.Clamp(clip.Volume, 0, 4);
        var audioFilter = $"volume={F(volume)}";
        if (clip.FadeIn > 0.001)
            audioFilter += $",afade=t=in:st=0:d={F(Math.Min(clip.FadeIn, clip.Duration))}";
        if (clip.FadeOut > 0.001)
            audioFilter += $",afade=t=out:st={F(Math.Max(0, clip.Duration - clip.FadeOut))}:d={F(Math.Min(clip.FadeOut, clip.Duration))}";

        if (asset.HasAudio)
        {
            await ProcessRunner.RunAsync(_locator.FfmpegPath!,
            [
                "-y",
                "-ss", F(clip.SourceStart),
                "-t", duration,
                "-i", asset.FilePath,
                "-vf", scale,
                "-af", audioFilter,
                "-t", duration,
                "-c:v", "libx264",
                "-preset", settings.Preset,
                "-crf", settings.Crf.ToString(CultureInfo.InvariantCulture),
                "-pix_fmt", "yuv420p",
                "-r", settings.Fps.ToString(CultureInfo.InvariantCulture),
                "-c:a", "aac",
                "-ar", "48000",
                "-ac", "2",
                "-movflags", "+faststart",
                outputPath
            ], log, cancellationToken);
        }
        else
        {
            await ProcessRunner.RunAsync(_locator.FfmpegPath!,
            [
                "-y",
                "-ss", F(clip.SourceStart),
                "-t", duration,
                "-i", asset.FilePath,
                "-f", "lavfi",
                "-i", "anullsrc=channel_layout=stereo:sample_rate=48000",
                "-map", "0:v:0",
                "-map", "1:a:0",
                "-vf", scale,
                "-t", duration,
                "-c:v", "libx264",
                "-preset", settings.Preset,
                "-crf", settings.Crf.ToString(CultureInfo.InvariantCulture),
                "-pix_fmt", "yuv420p",
                "-r", settings.Fps.ToString(CultureInfo.InvariantCulture),
                "-c:a", "aac",
                "-ar", "48000",
                "-ac", "2",
                "-shortest",
                outputPath
            ], log, cancellationToken);
        }
    }

    private async Task MixMusicAsync(
        BeatCutProject project,
        string basePath,
        IReadOnlyList<TimelineClip> musicClips,
        string outputPath,
        IProgress<string>? log,
        CancellationToken cancellationToken)
    {
        var args = new List<string> { "-y", "-i", basePath };
        foreach (var clip in musicClips)
        {
            var asset = project.FindAsset(clip.AssetId)
                ?? throw new InvalidOperationException("Musikmedium fehlt.");
            args.Add("-i");
            args.Add(asset.FilePath);
        }

        var filters = new List<string>();
        var mixInputs = new List<string> { "[0:a]" };

        for (var i = 0; i < musicClips.Count; i++)
        {
            var clip = musicClips[i];
            var inputIndex = i + 1;
            var label = $"m{i}";
            var volume = clip.Muted ? 0 : Math.Clamp(clip.Volume, 0, 4);
            var delayMs = Math.Max(0, (int)Math.Round(clip.Start * 1000));
            filters.Add($"[{inputIndex}:a]atrim=start={F(clip.SourceStart)}:duration={F(clip.Duration)},asetpts=PTS-STARTPTS,volume={F(volume)},adelay={delayMs}:all=1[{label}]");
            mixInputs.Add($"[{label}]");
        }

        filters.Add($"{string.Concat(mixInputs)}amix=inputs={mixInputs.Count}:duration=first:normalize=0[aout]");

        args.AddRange([
            "-filter_complex", string.Join(";", filters),
            "-map", "0:v:0",
            "-map", "[aout]",
            "-c:v", "copy",
            "-c:a", "aac",
            "-b:a", "192k",
            "-ar", "48000",
            "-ac", "2",
            "-movflags", "+faststart",
            outputPath
        ]);

        await ProcessRunner.RunAsync(_locator.FfmpegPath!, args, log, cancellationToken);
    }

    private static string F(double value) => value.ToString("0.######", CultureInfo.InvariantCulture);
}
