using System.Text.Json;
using BeatCutStudio.Models;

namespace BeatCutStudio.Services;

public sealed class MediaProbeService
{
    private readonly FfmpegLocator _locator;

    public MediaProbeService(FfmpegLocator locator)
    {
        _locator = locator;
    }

    public async Task<MediaAsset> CreateAssetAsync(string path, CancellationToken cancellationToken = default)
    {
        var ext = Path.GetExtension(path).ToLowerInvariant();
        var imageExtensions = new HashSet<string> { ".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp" };
        var audioExtensions = new HashSet<string> { ".mp3", ".wav", ".aac", ".m4a", ".flac", ".ogg", ".opus" };

        if (imageExtensions.Contains(ext))
        {
            using var image = Image.FromFile(path);
            return new MediaAsset
            {
                Name = Path.GetFileName(path),
                FilePath = path,
                Type = MediaAssetType.Image,
                Duration = 0,
                Width = image.Width,
                Height = image.Height,
                HasAudio = false
            };
        }

        var type = audioExtensions.Contains(ext) ? MediaAssetType.Audio : MediaAssetType.Video;

        if (!_locator.IsAvailable || _locator.FfprobePath is null)
        {
            return new MediaAsset
            {
                Name = Path.GetFileName(path),
                FilePath = path,
                Type = type,
                Duration = type == MediaAssetType.Audio ? 30 : 10
            };
        }

        var json = await ProcessRunner.RunCaptureAsync(_locator.FfprobePath,
        [
            "-v", "quiet",
            "-print_format", "json",
            "-show_format",
            "-show_streams",
            path
        ], cancellationToken);

        using var document = JsonDocument.Parse(json);
        var root = document.RootElement;

        double duration = 0;
        if (root.TryGetProperty("format", out var format) &&
            format.TryGetProperty("duration", out var durationValue) &&
            double.TryParse(durationValue.GetString(), System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var parsedDuration))
        {
            duration = parsedDuration;
        }

        var width = 0;
        var height = 0;
        var hasAudio = false;

        if (root.TryGetProperty("streams", out var streams))
        {
            foreach (var stream in streams.EnumerateArray())
            {
                if (!stream.TryGetProperty("codec_type", out var codecType)) continue;
                var codec = codecType.GetString();
                if (codec == "audio") hasAudio = true;
                if (codec == "video")
                {
                    if (stream.TryGetProperty("width", out var w)) width = w.GetInt32();
                    if (stream.TryGetProperty("height", out var h)) height = h.GetInt32();
                }
            }
        }

        return new MediaAsset
        {
            Name = Path.GetFileName(path),
            FilePath = path,
            Type = type,
            Duration = Math.Max(0, duration),
            Width = width,
            Height = height,
            HasAudio = hasAudio
        };
    }
}
