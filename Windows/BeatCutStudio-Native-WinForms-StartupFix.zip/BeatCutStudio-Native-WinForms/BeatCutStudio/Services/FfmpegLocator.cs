namespace BeatCutStudio.Services;

public sealed class FfmpegLocator
{
    public string? FfmpegPath { get; private set; }
    public string? FfprobePath { get; private set; }

    public bool IsAvailable => File.Exists(FfmpegPath) && File.Exists(FfprobePath);

    public FfmpegLocator()
    {
        Refresh();
    }

    public void Refresh()
    {
        FfmpegPath = Locate("ffmpeg.exe");
        FfprobePath = Locate("ffprobe.exe");
    }

    private static string? Locate(string fileName)
    {
        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "Tools", "FFmpeg", fileName),
            Path.Combine(AppContext.BaseDirectory, fileName),
            Path.Combine(Environment.CurrentDirectory, "Tools", "FFmpeg", fileName)
        };

        foreach (var candidate in candidates)
        {
            if (File.Exists(candidate))
                return candidate;
        }

        var path = Environment.GetEnvironmentVariable("PATH") ?? string.Empty;
        foreach (var folder in path.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
        {
            try
            {
                var candidate = Path.Combine(folder.Trim(), fileName);
                if (File.Exists(candidate))
                    return candidate;
            }
            catch
            {
            }
        }

        return null;
    }
}
