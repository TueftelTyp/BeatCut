using BeatCutStudio.Models;

namespace BeatCutStudio.Services;

public sealed class HistoryService
{
    private const int Limit = 80;
    private readonly ProjectService _projectService;
    private readonly List<string> _states = [];
    private int _index = -1;

    public HistoryService(ProjectService projectService)
    {
        _projectService = projectService;
    }

    public bool CanUndo => _index > 0;
    public bool CanRedo => _index >= 0 && _index < _states.Count - 1;

    public void Reset(BeatCutProject project)
    {
        _states.Clear();
        _index = -1;
        Record(project);
    }

    public void Record(BeatCutProject project)
    {
        var state = _projectService.Serialize(project);
        if (_index >= 0 && _states[_index] == state)
            return;

        if (_index < _states.Count - 1)
            _states.RemoveRange(_index + 1, _states.Count - _index - 1);

        _states.Add(state);
        if (_states.Count > Limit)
            _states.RemoveAt(0);
        else
            _index++;

        if (_states.Count == Limit)
            _index = _states.Count - 1;
    }

    public BeatCutProject? Undo()
    {
        if (!CanUndo) return null;
        _index--;
        return _projectService.Deserialize(_states[_index]);
    }

    public BeatCutProject? Redo()
    {
        if (!CanRedo) return null;
        _index++;
        return _projectService.Deserialize(_states[_index]);
    }
}
