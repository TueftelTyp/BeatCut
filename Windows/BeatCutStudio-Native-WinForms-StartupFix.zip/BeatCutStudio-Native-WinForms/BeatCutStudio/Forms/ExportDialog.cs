using BeatCutStudio.Infrastructure;
using BeatCutStudio.Models;

namespace BeatCutStudio.Forms;

public sealed class ExportDialog : Form
{
    private readonly TextBox _path = new();
    private readonly NumericUpDown _width = new() { Minimum = 320, Maximum = 7680, Increment = 2 };
    private readonly NumericUpDown _height = new() { Minimum = 240, Maximum = 4320, Increment = 2 };
    private readonly ComboBox _fps = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox _quality = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly CheckBox _music = new() { Text = "Musikspur einmischen", Checked = true, AutoSize = true };

    public ExportSettings Settings { get; private set; } = new();

    public ExportDialog(BeatCutProject project)
    {
        Text = "MP4 exportieren";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(520, 390);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;

        _width.Value = Math.Clamp(project.Width, 320, 7680);
        _height.Value = Math.Clamp(project.Height, 240, 4320);
        _fps.Items.AddRange(["24", "25", "30", "50", "60"]);
        _fps.SelectedItem = project.FramesPerSecond.ToString();
        if (_fps.SelectedIndex < 0) _fps.SelectedItem = "30";
        _quality.Items.AddRange(["Sehr hoch (CRF 16)", "Hoch (CRF 20)", "Mittel (CRF 24)", "Klein (CRF 28)"]);
        _quality.SelectedIndex = 1;

        var table = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(16), ColumnCount = 3, RowCount = 7 };
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 125));
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 92));

        table.Controls.Add(new Label { Text = "Ausgabedatei", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
        _path.Dock = DockStyle.Fill;
        table.Controls.Add(_path, 1, 0);
        var browse = new Button { Text = "Durchsuchen", Dock = DockStyle.Fill };
        table.Controls.Add(browse, 2, 0);

        AddRow(table, "Breite", _width, 1);
        AddRow(table, "Höhe", _height, 2);
        AddRow(table, "FPS", _fps, 3);
        AddRow(table, "Qualität", _quality, 4);
        table.Controls.Add(_music, 1, 5);

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        var ok = new Button { Text = "Export starten", DialogResult = DialogResult.OK, AutoSize = true };
        var cancel = new Button { Text = "Abbrechen", DialogResult = DialogResult.Cancel, AutoSize = true };
        buttons.Controls.Add(ok);
        buttons.Controls.Add(cancel);
        table.Controls.Add(buttons, 0, 6);
        table.SetColumnSpan(buttons, 3);

        browse.Click += (_, _) =>
        {
            using var dialog = new SaveFileDialog
            {
                Filter = "MP4 Video (*.mp4)|*.mp4",
                DefaultExt = "mp4",
                AddExtension = true,
                FileName = SanitizeFileName(project.Name) + ".mp4"
            };
            if (dialog.ShowDialog(this) == DialogResult.OK)
                _path.Text = dialog.FileName;
        };

        ok.Click += (_, e) =>
        {
            if (string.IsNullOrWhiteSpace(_path.Text))
            {
                MessageBox.Show(this, "Bitte zuerst eine Ausgabedatei wählen.", "BeatCut Studio", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.None;
                return;
            }

            Settings = new ExportSettings
            {
                OutputPath = _path.Text,
                Width = (int)_width.Value,
                Height = (int)_height.Value,
                Fps = int.Parse(_fps.SelectedItem?.ToString() ?? "30"),
                Crf = _quality.SelectedIndex switch { 0 => 16, 1 => 20, 2 => 24, _ => 28 },
                IncludeMusic = _music.Checked
            };
        };

        Controls.Add(table);
        AcceptButton = ok;
        CancelButton = cancel;
        Theme.Apply(this);
    }

    private static void AddRow(TableLayoutPanel table, string label, Control control, int row)
    {
        table.Controls.Add(new Label { Text = label, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, row);
        control.Dock = DockStyle.Fill;
        table.Controls.Add(control, 1, row);
        table.SetColumnSpan(control, 2);
    }

    private static string SanitizeFileName(string value)
    {
        foreach (var c in Path.GetInvalidFileNameChars())
            value = value.Replace(c, '_');
        return string.IsNullOrWhiteSpace(value) ? "BeatCut-Export" : value;
    }
}
