using BeatCutStudio.Controls;
using BeatCutStudio.Infrastructure;
using BeatCutStudio.Models;
using BeatCutStudio.Services;
using LibVLCSharp.Shared;
using LibVLCSharp.WinForms;
using BeatCutTrackType = BeatCutStudio.Models.TrackType;

namespace BeatCutStudio.Forms;

public sealed class MainForm : Form
{
    private readonly ProjectService _projectService = new();
    private readonly FfmpegLocator _ffmpegLocator = new();
    private readonly MediaProbeService _probeService;
    private readonly SmartCutService _smartCutService = new();
    private readonly ExportService _exportService;
    private readonly HistoryService _history;

    private BeatCutProject _project = BeatCutProject.CreateDefault();
    private string? _projectPath;

    private LibVLC? _libVlc;
    private MediaPlayer? _videoPlayer;
    private MediaPlayer? _musicPlayer;
    private bool _playbackEngineReady;
    private bool _playbackEngineInitializationAttempted;
    private Media? _currentVideoMedia;
    private Media? _currentMusicMedia;
    private Guid? _currentVideoClipId;
    private Guid? _currentMusicClipId;

    private readonly ListView _mediaList = new();
    private readonly TimelineControl _timeline = new();
    private readonly VideoView _videoView = new();
    private readonly PictureBox _imagePreview = new();
    private readonly Label _previewMessage = new();
    private readonly SplitContainer _mainSplit = new();
    private readonly SplitContainer _workspaceSplit = new();
    private readonly SplitContainer _centerRightSplit = new();
    private readonly PropertyGrid _propertyGrid = new();
    private readonly Label _timeLabel = new();
    private readonly Label _statusLabel = new();
    private readonly TextBox _projectName = new();
    private readonly NumericUpDown _zoom = new();
    private readonly System.Windows.Forms.Timer _playTimer = new() { Interval = 30 };
    private readonly ToolStripButton _undoButton = new("↶ Rückgängig");
    private readonly ToolStripButton _redoButton = new("↷ Wiederholen");
    private readonly ToolStripButton _playButton = new("▶ Wiedergabe");
    private readonly ToolStripStatusLabel _ffmpegStatus = new();

    private bool _playing;
    private DateTime _lastTick;

    public MainForm()
    {
        _probeService = new MediaProbeService(_ffmpegLocator);
        _exportService = new ExportService(_ffmpegLocator);
        _history = new HistoryService(_projectService);

        Text = "BeatCut Studio · Native WinForms";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(1600, 1000);
        WindowState = FormWindowState.Maximized;
        MinimumSize = new Size(1180, 760);
        KeyPreview = true;

        BuildUi();
        WireEvents();
        ApplyProject(_project, resetHistory: true);
        Theme.Apply(this);

        _playTimer.Tick += PlayTimer_Tick;
        Shown += MainForm_Shown;
        FormClosed += (_, _) => DisposePlayers();
    }

    private void MainForm_Shown(object? sender, EventArgs e)
    {
        ApplySafeSplitterDistances();

        // LibVLC wird absichtlich erst nach dem ersten Anzeigen des Fensters
        // initialisiert. Dadurch kann ein Problem mit der Video-Engine nicht mehr
        // verhindern, dass die WinForms-Oberfläche sichtbar wird.
        BeginInvoke(new Action(InitializePlaybackEngine));
    }

    private void ApplySafeSplitterDistances()
    {
        SetSafeSplitterDistance(_mainSplit, 0.62, 280, 220);
        SetSafeSplitterDistance(_workspaceSplit, 0.18, 210, 420);
        SetSafeSplitterDistance(_centerRightSplit, 0.72, 420, 280);
    }

    private static void SetSafeSplitterDistance(
        SplitContainer split,
        double ratio,
        int panel1MinSize,
        int panel2MinSize)
    {
        var available = split.Orientation == Orientation.Vertical
            ? split.ClientSize.Width
            : split.ClientSize.Height;

        // Während der Konstruktion haben SplitContainer noch sehr kleine
        // Standardabmessungen. Mindestgrößen und SplitterDistance werden daher
        // erst gesetzt, wenn das Hauptfenster tatsächlich seine Größe besitzt.
        split.Panel1MinSize = 0;
        split.Panel2MinSize = 0;

        var min = Math.Max(0, panel1MinSize);
        var max = available - Math.Max(0, panel2MinSize) - split.SplitterWidth;
        if (max <= min)
            return;

        var desired = (int)Math.Round(available * ratio);
        split.SplitterDistance = Math.Clamp(desired, min, max);
        split.Panel1MinSize = panel1MinSize;
        split.Panel2MinSize = panel2MinSize;
    }

    private void InitializePlaybackEngine()
    {
        if (_playbackEngineInitializationAttempted)
            return;

        _playbackEngineInitializationAttempted = true;

        try
        {
            Core.Initialize();
            _libVlc = new LibVLC("--no-video-title-show", "--quiet");
            _videoPlayer = new MediaPlayer(_libVlc);
            _musicPlayer = new MediaPlayer(_libVlc);
            _videoView.MediaPlayer = _videoPlayer;
            _playbackEngineReady = true;
            _previewMessage.Visible = false;
            SetStatus("Videovorschau bereit");
            SyncPreview(force: true);
        }
        catch (Exception ex)
        {
            _playbackEngineReady = false;
            _previewMessage.Text =
                "Die Oberfläche ist bereit, aber LibVLC konnte nicht initialisiert werden.\n\n" +
                "Video-Vorschau ist vorübergehend deaktiviert.\n" +
                "Medien, Timeline, Projekte und FFmpeg-Export bleiben verfügbar.";
            _previewMessage.Visible = true;
            _previewMessage.BringToFront();
            SetStatus("LibVLC-Vorschau nicht verfügbar");

            MessageBox.Show(
                this,
                "BeatCut Studio wurde gestartet, aber die Video-Vorschau konnte nicht initialisiert werden.\n\n" +
                ex.Message +
                "\n\nDie Anwendung bleibt geöffnet. Bitte prüfe anschließend die LibVLC-NuGet-Pakete bzw. den x64-Build.",
                "BeatCut Studio · Video-Vorschau",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }

    private void SyncImageOnlyPreview()
    {
        var videoTrack = _project.Tracks.FirstOrDefault(t => t.Type == BeatCutTrackType.Video);
        if (videoTrack is null)
            return;

        var clip = _project.Clips
            .Where(c => c.TrackId == videoTrack.Id && _timeline.PlayheadSeconds >= c.Start && _timeline.PlayheadSeconds < c.End)
            .OrderByDescending(c => c.Start)
            .FirstOrDefault();

        if (clip is null)
        {
            _imagePreview.Visible = false;
            _previewMessage.Visible = true;
            _previewMessage.BringToFront();
            return;
        }

        var asset = _project.FindAsset(clip.AssetId);
        if (asset?.Type == MediaAssetType.Image)
        {
            ShowImage(asset.FilePath);
        }
        else
        {
            _imagePreview.Visible = false;
            _previewMessage.Visible = true;
            _previewMessage.BringToFront();
        }
    }

    private void BuildUi()
    {
        var toolStrip = new ToolStrip
        {
            GripStyle = ToolStripGripStyle.Hidden,
            Dock = DockStyle.Top,
            BackColor = Theme.Panel,
            ForeColor = Theme.Text,
            Renderer = new ToolStripProfessionalRenderer(new DarkToolStripColors())
        };

        toolStrip.Items.AddRange([
            MakeToolButton("Neu", (_, _) => NewProject()),
            MakeToolButton("Öffnen", async (_, _) => await OpenProjectAsync()),
            MakeToolButton("Speichern", async (_, _) => await SaveProjectAsync(false)),
            MakeToolButton("Speichern unter", async (_, _) => await SaveProjectAsync(true)),
            new ToolStripSeparator(),
            MakeToolButton("+ Medien", async (_, _) => await ImportMediaAsync(false)),
            MakeToolButton("+ Musik", async (_, _) => await ImportMediaAsync(true)),
            new ToolStripSeparator(),
            _undoButton,
            _redoButton,
            MakeToolButton("Kopieren → Marker", (_, _) => CopySelectionToPlayhead()),
            MakeToolButton("Teilen", (_, _) => SplitSelection()),
            MakeToolButton("Löschen", (_, _) => DeleteSelection()),
            new ToolStripSeparator(),
            MakeToolButton("⚡ SmartCut", (_, _) => RunSmartCut()),
            MakeToolButton("MP4 Export", async (_, _) => await ExportAsync())
        ]);

        var namePanel = new Panel { Dock = DockStyle.Top, Height = 42, BackColor = Theme.Panel2, Padding = new Padding(10, 7, 10, 7) };
        var nameLabel = new Label { Text = "Projekt:", AutoSize = true, Location = new Point(10, 12) };
        _projectName.Location = new Point(70, 8);
        _projectName.Width = 260;
        namePanel.Controls.Add(nameLabel);
        namePanel.Controls.Add(_projectName);

        _mainSplit.Dock = DockStyle.Fill;
        _mainSplit.Orientation = Orientation.Horizontal;
        _mainSplit.BackColor = Theme.Border;

        _workspaceSplit.Dock = DockStyle.Fill;
        _workspaceSplit.Orientation = Orientation.Vertical;
        _workspaceSplit.BackColor = Theme.Border;

        _centerRightSplit.Dock = DockStyle.Fill;
        _centerRightSplit.Orientation = Orientation.Vertical;
        _centerRightSplit.BackColor = Theme.Border;

        _workspaceSplit.Panel2.Controls.Add(_centerRightSplit);
        _workspaceSplit.Panel1.Controls.Add(BuildMediaPanel());
        _centerRightSplit.Panel1.Controls.Add(BuildPreviewPanel());
        _centerRightSplit.Panel2.Controls.Add(BuildPropertiesPanel());
        _mainSplit.Panel1.Controls.Add(_workspaceSplit);
        _mainSplit.Panel2.Controls.Add(BuildTimelinePanel());

        var status = new StatusStrip { BackColor = Theme.Panel, ForeColor = Theme.Text };
        _statusLabel.Text = "Bereit";
        _ffmpegStatus.Text = "FFmpeg: prüfe...";
        status.Items.Add(new ToolStripControlHost(_statusLabel));
        status.Items.Add(new ToolStripStatusLabel { Spring = true });
        status.Items.Add(_ffmpegStatus);

        Controls.Add(_mainSplit);
        Controls.Add(namePanel);
        Controls.Add(toolStrip);
        Controls.Add(status);
    }

    private Control BuildMediaPanel()
    {
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8), BackColor = Theme.Panel };
        var title = new Label { Text = "MEDIEN", Dock = DockStyle.Top, Height = 28, Font = new Font(Font, FontStyle.Bold) };

        _mediaList.Dock = DockStyle.Fill;
        _mediaList.View = View.Details;
        _mediaList.FullRowSelect = true;
        _mediaList.HideSelection = false;
        _mediaList.MultiSelect = false;
        _mediaList.Columns.Add("Name", 165);
        _mediaList.Columns.Add("Typ", 70);
        _mediaList.AllowDrop = false;

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 42, FlowDirection = FlowDirection.LeftToRight };
        var add = new Button { Text = "+ Medien", Width = 92 };
        var music = new Button { Text = "+ Musik", Width = 86 };
        add.Click += async (_, _) => await ImportMediaAsync(false);
        music.Click += async (_, _) => await ImportMediaAsync(true);
        buttons.Controls.Add(add);
        buttons.Controls.Add(music);

        panel.Controls.Add(_mediaList);
        panel.Controls.Add(buttons);
        panel.Controls.Add(title);
        return panel;
    }

    private Control BuildPreviewPanel()
    {
        var root = new Panel { Dock = DockStyle.Fill, BackColor = Color.Black };
        var previewHost = new Panel { Dock = DockStyle.Fill, BackColor = Color.Black };

        _videoView.Dock = DockStyle.Fill;
        _videoView.BackColor = Color.Black;

        _imagePreview.Dock = DockStyle.Fill;
        _imagePreview.BackColor = Color.Black;
        _imagePreview.SizeMode = PictureBoxSizeMode.Zoom;
        _imagePreview.Visible = false;

        _previewMessage.Dock = DockStyle.Fill;
        _previewMessage.BackColor = Color.Black;
        _previewMessage.ForeColor = Theme.Muted;
        _previewMessage.TextAlign = ContentAlignment.MiddleCenter;
        _previewMessage.Font = new Font(Font.FontFamily, 11, FontStyle.Regular);
        _previewMessage.Text = "Videovorschau wird initialisiert …";

        previewHost.Controls.Add(_videoView);
        previewHost.Controls.Add(_imagePreview);
        previewHost.Controls.Add(_previewMessage);
        _previewMessage.BringToFront();

        var transport = new Panel { Dock = DockStyle.Bottom, Height = 58, BackColor = Theme.Panel };
        var controls = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Padding = new Padding(8, 10, 8, 8)
        };

        var begin = new Button { Text = "|◀", Width = 42 };
        var back = new Button { Text = "-1f", Width = 42 };
        _playButton.AutoSize = true;
        _playButton.DisplayStyle = ToolStripItemDisplayStyle.Text;
        var play = new Button { Text = "▶ / ❚❚", Width = 75 };
        var forward = new Button { Text = "+1f", Width = 42 };
        var end = new Button { Text = "▶|", Width = 42 };
        _timeLabel.Text = "00:00.000";
        _timeLabel.AutoSize = true;
        _timeLabel.Padding = new Padding(10, 8, 0, 0);

        begin.Click += (_, _) => SetProjectTime(0, true);
        back.Click += (_, _) => SetProjectTime(Math.Max(0, _timeline.PlayheadSeconds - 1.0 / _project.FramesPerSecond), true);
        play.Click += (_, _) => TogglePlayback();
        forward.Click += (_, _) => SetProjectTime(_timeline.PlayheadSeconds + 1.0 / _project.FramesPerSecond, true);
        end.Click += (_, _) => SetProjectTime(_project.ProjectDuration, true);

        controls.Controls.AddRange([begin, back, play, forward, end, _timeLabel]);
        transport.Controls.Add(controls);
        root.Controls.Add(previewHost);
        root.Controls.Add(transport);
        return root;
    }

    private Control BuildPropertiesPanel()
    {
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8), BackColor = Theme.Panel };
        var title = new Label { Text = "EIGENSCHAFTEN", Dock = DockStyle.Top, Height = 28, Font = new Font(Font, FontStyle.Bold) };
        _propertyGrid.Dock = DockStyle.Fill;
        _propertyGrid.ToolbarVisible = false;
        _propertyGrid.HelpVisible = true;
        panel.Controls.Add(_propertyGrid);
        panel.Controls.Add(title);
        return panel;
    }

    private Control BuildTimelinePanel()
    {
        var root = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Background };
        var toolbar = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 42,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Padding = new Padding(7, 5, 7, 4),
            BackColor = Theme.Panel
        };

        var clear = new Button { Text = "Auswahl aufheben", AutoSize = true };
        var split = new Button { Text = "Teilen", AutoSize = true };
        var copy = new Button { Text = "Kopieren", AutoSize = true };
        var delete = new Button { Text = "Löschen", AutoSize = true };
        var zoomLabel = new Label { Text = "Zoom", AutoSize = true, Padding = new Padding(14, 8, 0, 0) };
        _zoom.Minimum = 20;
        _zoom.Maximum = 300;
        _zoom.Value = 80;
        _zoom.Width = 72;

        clear.Click += (_, _) => _timeline.ClearSelection();
        split.Click += (_, _) => SplitSelection();
        copy.Click += (_, _) => CopySelectionToPlayhead();
        delete.Click += (_, _) => DeleteSelection();
        _zoom.ValueChanged += (_, _) => _timeline.PixelsPerSecond = (double)_zoom.Value;

        toolbar.Controls.AddRange([clear, split, copy, delete, zoomLabel, _zoom]);

        var scroll = new Panel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            BackColor = Theme.Background
        };
        _timeline.Location = Point.Empty;
        _timeline.Size = new Size(1600, 500);
        _timeline.Anchor = AnchorStyles.Top | AnchorStyles.Left;
        scroll.Controls.Add(_timeline);

        scroll.Scroll += (_, _) => _timeline.Invalidate();
        scroll.Resize += (_, _) =>
        {
            _timeline.Height = Math.Max(scroll.ClientSize.Height, 400);
            _timeline.Width = Math.Max(scroll.AutoScrollMinSize.Width, scroll.ClientSize.Width);
        };

        root.Controls.Add(scroll);
        root.Controls.Add(toolbar);
        return root;
    }

    private void WireEvents()
    {
        _mediaList.ItemDrag += (_, e) =>
        {
            if (e.Item is not ListViewItem item || item.Tag is not Guid assetId) return;
            var data = new DataObject();
            data.SetData("BeatCutAssetId", assetId.ToString());
            _mediaList.DoDragDrop(data, DragDropEffects.Copy);
        };

        _mediaList.DoubleClick += (_, _) =>
        {
            if (_mediaList.SelectedItems.Count == 0 || _mediaList.SelectedItems[0].Tag is not Guid id) return;
            var asset = _project.FindAsset(id);
            if (asset is null) return;
            AddAssetToTimeline(asset, _timeline.PlayheadSeconds, null);
        };

        _timeline.SelectionChanged += (_, _) =>
        {
            _propertyGrid.SelectedObject = _timeline.PrimaryClip;
        };

        _timeline.PlayheadChanged += (_, _) => SetProjectTime(_timeline.PlayheadSeconds, true);
        _timeline.EditCommitted += (_, _) => CommitProjectChange();
        _timeline.AssetDropped += (_, e) =>
        {
            var asset = _project.FindAsset(e.AssetId);
            if (asset is not null)
                AddAssetToTimeline(asset, e.Time, e.TrackId);
        };

        _propertyGrid.PropertyValueChanged += (_, _) =>
        {
            NormalizeClips();
            CommitProjectChange();
            _timeline.Invalidate();
            SyncPreview(force: true);
        };

        _projectName.TextChanged += (_, _) =>
        {
            if (_projectName.Focused)
            {
                _project.Name = _projectName.Text.Trim();
                Text = $"BeatCut Studio · {_project.Name}";
            }
        };

        _undoButton.Click += (_, _) => Undo();
        _redoButton.Click += (_, _) => Redo();

        KeyDown += MainForm_KeyDown;
    }

    private void MainForm_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.Control && e.KeyCode == Keys.Z && !e.Shift)
        {
            Undo(); e.SuppressKeyPress = true;
        }
        else if ((e.Control && e.KeyCode == Keys.Y) || (e.Control && e.Shift && e.KeyCode == Keys.Z))
        {
            Redo(); e.SuppressKeyPress = true;
        }
        else if (e.Control && e.KeyCode == Keys.D)
        {
            CopySelectionToPlayhead(); e.SuppressKeyPress = true;
        }
        else if (e.KeyCode == Keys.Delete)
        {
            DeleteSelection(); e.SuppressKeyPress = true;
        }
        else if (e.KeyCode == Keys.Space && ActiveControl is not TextBoxBase)
        {
            TogglePlayback(); e.SuppressKeyPress = true;
        }
    }

    private ToolStripButton MakeToolButton(string text, EventHandler click)
    {
        var button = new ToolStripButton(text) { ForeColor = Theme.Text, DisplayStyle = ToolStripItemDisplayStyle.Text };
        button.Click += click;
        return button;
    }

    private async Task ImportMediaAsync(bool audioOnly)
    {
        using var dialog = new OpenFileDialog
        {
            Multiselect = true,
            Filter = audioOnly
                ? "Audio|*.mp3;*.wav;*.m4a;*.aac;*.flac;*.ogg;*.opus|Alle Dateien|*.*"
                : "Medien|*.mp4;*.mov;*.mkv;*.avi;*.webm;*.png;*.jpg;*.jpeg;*.bmp;*.webp|Alle Dateien|*.*"
        };

        if (dialog.ShowDialog(this) != DialogResult.OK) return;

        UseWaitCursor = true;
        try
        {
            foreach (var path in dialog.FileNames)
            {
                var asset = await _probeService.CreateAssetAsync(path);
                if (audioOnly && asset.Type != MediaAssetType.Audio)
                    continue;
                _project.Assets.Add(asset);
            }
            RefreshMediaList();
            CommitProjectChange();
            SetStatus($"{dialog.FileNames.Length} Datei(en) importiert");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Medienimport", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            UseWaitCursor = false;
        }
    }

    private void AddAssetToTimeline(MediaAsset asset, double time, Guid? requestedTrackId)
    {
        TimelineTrack? track = null;
        if (requestedTrackId is { } trackId)
        {
            var requested = _project.FindTrack(trackId);
            if (requested is not null &&
                ((asset.Type == MediaAssetType.Audio && requested.Type == BeatCutTrackType.Music) ||
                 (asset.Type != MediaAssetType.Audio && requested.Type == BeatCutTrackType.Video)))
                track = requested;
        }

        track ??= asset.Type == MediaAssetType.Audio
            ? _project.Tracks.First(t => t.Type == BeatCutTrackType.Music)
            : _project.Tracks.First(t => t.Type == BeatCutTrackType.Video);

        var duration = asset.Type switch
        {
            MediaAssetType.Image => 3.0,
            _ => Math.Max(0.2, asset.Duration)
        };

        if (_project.DurationLimitSeconds is { } limit)
            duration = Math.Min(duration, Math.Max(0.1, limit - time));

        var clip = new TimelineClip
        {
            TrackId = track.Id,
            AssetId = asset.Id,
            Start = Math.Max(0, time),
            Duration = duration,
            SourceStart = 0
        };

        _project.Clips.Add(clip);
        CommitProjectChange();
        _timeline.SelectClip(clip.Id);
        _timeline.Invalidate();
        SetProjectTime(clip.Start, true);
    }

    private void DeleteSelection()
    {
        if (_timeline.SelectedClipIds.Count == 0) return;
        _project.Clips.RemoveAll(c => _timeline.SelectedClipIds.Contains(c.Id));
        _timeline.ClearSelection();
        CommitProjectChange();
        SyncPreview(force: true);
    }

    private void CopySelectionToPlayhead()
    {
        var source = _project.Clips.Where(c => _timeline.SelectedClipIds.Contains(c.Id)).OrderBy(c => c.Start).ToList();
        if (source.Count == 0) return;

        var earliest = source.Min(c => c.Start);
        var copies = new List<TimelineClip>();
        foreach (var clip in source)
        {
            copies.Add(new TimelineClip
            {
                TrackId = clip.TrackId,
                AssetId = clip.AssetId,
                Start = Math.Max(0, _timeline.PlayheadSeconds + clip.Start - earliest),
                Duration = clip.Duration,
                SourceStart = clip.SourceStart,
                Volume = clip.Volume,
                Muted = clip.Muted,
                FadeIn = clip.FadeIn,
                FadeOut = clip.FadeOut,
                Opacity = clip.Opacity,
                Scale = clip.Scale,
                Rotation = clip.Rotation
            });
        }

        _project.Clips.AddRange(copies);
        CommitProjectChange();
        if (copies.Count > 0) _timeline.SelectClip(copies[0].Id);
        _timeline.Invalidate();
    }

    private void SplitSelection()
    {
        var selected = _project.Clips.Where(c => _timeline.SelectedClipIds.Contains(c.Id)).ToList();
        var time = _timeline.PlayheadSeconds;
        var created = new List<TimelineClip>();

        foreach (var clip in selected)
        {
            if (time <= clip.Start + 0.05 || time >= clip.End - 0.05) continue;
            var leftDuration = time - clip.Start;
            var rightDuration = clip.End - time;
            clip.Duration = leftDuration;
            created.Add(new TimelineClip
            {
                TrackId = clip.TrackId,
                AssetId = clip.AssetId,
                Start = time,
                Duration = rightDuration,
                SourceStart = clip.SourceStart + leftDuration,
                Volume = clip.Volume,
                Muted = clip.Muted,
                FadeIn = 0,
                FadeOut = clip.FadeOut,
                Opacity = clip.Opacity,
                Scale = clip.Scale,
                Rotation = clip.Rotation
            });
            clip.FadeOut = 0;
        }

        if (created.Count == 0) return;
        _project.Clips.AddRange(created);
        CommitProjectChange();
        _timeline.SelectClip(created[0].Id);
        _timeline.Invalidate();
    }

    private void RunSmartCut()
    {
        using var dialog = new SmartCutDialog(_project.Bpm, _project.DurationLimitSeconds ?? 30);
        if (dialog.ShowDialog(this) != DialogResult.OK) return;

        try
        {
            _smartCutService.Generate(_project, dialog.Settings);
            CommitProjectChange();
            _timeline.Invalidate();
            SetProjectTime(0, true);
            SetStatus("SmartCut erzeugt");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "SmartCut", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private async Task ExportAsync()
    {
        using var dialog = new ExportDialog(_project);
        if (dialog.ShowDialog(this) != DialogResult.OK) return;

        using var progressDialog = new ProgressDialog("BeatCut Studio · MP4 Export");
        progressDialog.Show(this);
        progressDialog.Refresh();

        try
        {
            await _exportService.ExportAsync(
                _project,
                dialog.Settings,
                progressDialog.CreateProgress(),
                progressDialog.CreateLog(),
                progressDialog.Cancellation.Token);

            progressDialog.Close();
            SetStatus("MP4 Export abgeschlossen");
            MessageBox.Show(this, $"Export abgeschlossen:\n\n{dialog.Settings.OutputPath}", "BeatCut Studio", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (OperationCanceledException)
        {
            progressDialog.Close();
            SetStatus("Export abgebrochen");
        }
        catch (Exception ex)
        {
            progressDialog.Close();
            MessageBox.Show(this, ex.Message, "MP4 Export", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void TogglePlayback()
    {
        if (_playing)
        {
            StopPlayback();
            return;
        }

        if (_timeline.PlayheadSeconds >= _project.ProjectDuration - 0.02)
            SetProjectTime(0, true);

        _playing = true;
        _lastTick = DateTime.UtcNow;
        _playTimer.Start();
        SyncPreview(force: true);
        SetStatus("Wiedergabe");
    }

    private void StopPlayback()
    {
        _playing = false;
        _playTimer.Stop();
        _videoPlayer?.Pause();
        _musicPlayer?.Pause();
        SetStatus("Pausiert");
    }

    private void PlayTimer_Tick(object? sender, EventArgs e)
    {
        if (!_playing) return;
        var now = DateTime.UtcNow;
        var delta = (now - _lastTick).TotalSeconds;
        _lastTick = now;

        var next = _timeline.PlayheadSeconds + delta;
        if (next >= _project.ProjectDuration)
        {
            SetProjectTime(_project.ProjectDuration, true);
            StopPlayback();
            return;
        }

        SetProjectTime(next, false);
        SyncPreview(force: false);
    }

    private void SetProjectTime(double time, bool forcePreview)
    {
        _timeline.PlayheadSeconds = Math.Max(0, time);
        _timeLabel.Text = TimeSpan.FromSeconds(_timeline.PlayheadSeconds).ToString(@"mm\:ss\.fff");
        SyncPreview(forcePreview);
    }

    private void SyncPreview(bool force)
    {
        if (!_playbackEngineReady || _videoPlayer is null || _musicPlayer is null || _libVlc is null)
        {
            SyncImageOnlyPreview();
            return;
        }

        var videoTrack = _project.Tracks.FirstOrDefault(t => t.Type == BeatCutTrackType.Video);
        if (videoTrack is not null)
        {
            var clip = _project.Clips
                .Where(c => c.TrackId == videoTrack.Id && _timeline.PlayheadSeconds >= c.Start && _timeline.PlayheadSeconds < c.End)
                .OrderByDescending(c => c.Start)
                .FirstOrDefault();

            if (clip is null)
            {
                _videoPlayer.Pause();
                _imagePreview.Visible = false;
                _videoView.Visible = true;
                _currentVideoClipId = null;
            }
            else
            {
                var asset = _project.FindAsset(clip.AssetId);
                if (asset is not null)
                {
                    var sourceTime = Math.Max(0, clip.SourceStart + (_timeline.PlayheadSeconds - clip.Start));
                    if (asset.Type == MediaAssetType.Image)
                    {
                        _videoPlayer.Pause();
                        ShowImage(asset.FilePath);
                        _currentVideoClipId = clip.Id;
                    }
                    else if (asset.Type == MediaAssetType.Video)
                    {
                        _imagePreview.Visible = false;
                        _videoView.Visible = true;

                        if (_currentVideoClipId != clip.Id || force)
                        {
                            _currentVideoMedia?.Dispose();
                            _currentVideoMedia = new Media(_libVlc, asset.FilePath, FromType.FromPath);
                            _videoPlayer.Media = _currentVideoMedia;
                            _videoPlayer.Volume = clip.Muted ? 0 : (int)Math.Clamp(clip.Volume * 100, 0, 200);
                            _videoPlayer.Play();
                            _videoPlayer.Time = (long)(sourceTime * 1000);
                            if (!_playing) _videoPlayer.Pause();
                            _currentVideoClipId = clip.Id;
                        }
                        else
                        {
                            var target = (long)(sourceTime * 1000);
                            if (Math.Abs(_videoPlayer.Time - target) > 350)
                                _videoPlayer.Time = target;
                            if (_playing && !_videoPlayer.IsPlaying)
                                _videoPlayer.Play();
                        }
                    }
                }
            }
        }

        SyncMusic(force);
    }

    private void SyncMusic(bool force)
    {
        if (!_playbackEngineReady || _musicPlayer is null || _libVlc is null)
            return;

        var musicTrack = _project.Tracks.FirstOrDefault(t => t.Type == BeatCutTrackType.Music);
        if (musicTrack is null || musicTrack.Muted)
        {
            _musicPlayer.Pause();
            return;
        }

        var clip = _project.Clips
            .Where(c => c.TrackId == musicTrack.Id && _timeline.PlayheadSeconds >= c.Start && _timeline.PlayheadSeconds < c.End)
            .OrderByDescending(c => c.Start)
            .FirstOrDefault();

        if (clip is null)
        {
            _musicPlayer.Pause();
            _currentMusicClipId = null;
            return;
        }

        var asset = _project.FindAsset(clip.AssetId);
        if (asset is null) return;
        var sourceTime = Math.Max(0, clip.SourceStart + (_timeline.PlayheadSeconds - clip.Start));

        if (_currentMusicClipId != clip.Id || force)
        {
            _currentMusicMedia?.Dispose();
            _currentMusicMedia = new Media(_libVlc, asset.FilePath, FromType.FromPath);
            _musicPlayer.Media = _currentMusicMedia;
            _musicPlayer.Volume = clip.Muted ? 0 : (int)Math.Clamp(clip.Volume * 100, 0, 200);
            _musicPlayer.Play();
            _musicPlayer.Time = (long)(sourceTime * 1000);
            if (!_playing) _musicPlayer.Pause();
            _currentMusicClipId = clip.Id;
        }
        else if (_playing)
        {
            var target = (long)(sourceTime * 1000);
            if (Math.Abs(_musicPlayer.Time - target) > 350)
                _musicPlayer.Time = target;
            if (!_musicPlayer.IsPlaying)
                _musicPlayer.Play();
        }
    }

    private void ShowImage(string path)
    {
        try
        {
            using var source = Image.FromFile(path);
            var clone = new Bitmap(source);
            var old = _imagePreview.Image;
            _imagePreview.Image = clone;
            old?.Dispose();
            _imagePreview.Visible = true;
            _imagePreview.BringToFront();
            _videoView.Visible = false;
        }
        catch
        {
            _imagePreview.Visible = false;
        }
    }

    private void NormalizeClips()
    {
        foreach (var clip in _project.Clips)
        {
            clip.Start = Math.Max(0, clip.Start);
            clip.Duration = Math.Max(0.1, clip.Duration);
            clip.SourceStart = Math.Max(0, clip.SourceStart);
            clip.Volume = Math.Clamp(clip.Volume, 0, 4);
            clip.Opacity = Math.Clamp(clip.Opacity, 0, 1);
            clip.Scale = Math.Clamp(clip.Scale, 0.05, 10);
        }
    }

    private void CommitProjectChange()
    {
        NormalizeClips();
        _history.Record(_project);
        RefreshUndoRedo();
        _timeline.Project = _project;
        RefreshMediaList();
    }

    private void Undo()
    {
        var restored = _history.Undo();
        if (restored is not null) ApplyProject(restored, resetHistory: false);
    }

    private void Redo()
    {
        var restored = _history.Redo();
        if (restored is not null) ApplyProject(restored, resetHistory: false);
    }

    private void ApplyProject(BeatCutProject project, bool resetHistory)
    {
        StopPlayback();
        _project = project;
        _projectName.Text = _project.Name;
        _timeline.Project = _project;
        _timeline.PixelsPerSecond = (double)_zoom.Value;
        RefreshMediaList();
        _propertyGrid.SelectedObject = null;
        SetProjectTime(0, true);
        Text = $"BeatCut Studio · {_project.Name}";
        if (resetHistory) _history.Reset(_project);
        RefreshUndoRedo();
        RefreshFfmpegStatus();
    }

    private void RefreshMediaList()
    {
        _mediaList.BeginUpdate();
        _mediaList.Items.Clear();
        foreach (var asset in _project.Assets)
        {
            var item = new ListViewItem(asset.Name) { Tag = asset.Id };
            item.SubItems.Add(asset.Type.ToString());
            _mediaList.Items.Add(item);
        }
        _mediaList.EndUpdate();
    }

    private void RefreshUndoRedo()
    {
        _undoButton.Enabled = _history.CanUndo;
        _redoButton.Enabled = _history.CanRedo;
    }

    private void RefreshFfmpegStatus()
    {
        _ffmpegLocator.Refresh();
        _ffmpegStatus.Text = _ffmpegLocator.IsAvailable ? "FFmpeg: bereit" : "FFmpeg: fehlt (Tools\\FFmpeg)";
        _ffmpegStatus.ForeColor = _ffmpegLocator.IsAvailable ? Theme.Green : Theme.Danger;
    }

    private void SetStatus(string value)
    {
        _statusLabel.Text = value;
    }

    private void NewProject()
    {
        if (MessageBox.Show(this, "Neues Projekt erstellen? Ungespeicherte Änderungen gehen verloren.", "BeatCut Studio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            return;
        _projectPath = null;
        ApplyProject(BeatCutProject.CreateDefault(), resetHistory: true);
    }

    private async Task OpenProjectAsync()
    {
        using var dialog = new OpenFileDialog { Filter = "BeatCut Projekt (*.beatcut)|*.beatcut|JSON (*.json)|*.json" };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var project = await _projectService.LoadAsync(dialog.FileName);
            _projectPath = dialog.FileName;
            ApplyProject(project, resetHistory: true);
            SetStatus("Projekt geöffnet");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Projekt öffnen", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task SaveProjectAsync(bool saveAs)
    {
        if (saveAs || string.IsNullOrWhiteSpace(_projectPath))
        {
            using var dialog = new SaveFileDialog
            {
                Filter = "BeatCut Projekt (*.beatcut)|*.beatcut",
                DefaultExt = "beatcut",
                AddExtension = true,
                FileName = _project.Name + ".beatcut"
            };
            if (dialog.ShowDialog(this) != DialogResult.OK) return;
            _projectPath = dialog.FileName;
        }

        _project.Name = _projectName.Text.Trim();
        await _projectService.SaveAsync(_project, _projectPath!);
        SetStatus("Projekt gespeichert");
    }

    private void DisposePlayers()
    {
        _playTimer.Stop();
        _imagePreview.Image?.Dispose();
        _currentVideoMedia?.Dispose();
        _currentMusicMedia?.Dispose();
        _videoPlayer?.Dispose();
        _musicPlayer?.Dispose();
        _libVlc?.Dispose();
    }

    private sealed class DarkToolStripColors : ProfessionalColorTable
    {
        public override Color ToolStripGradientBegin => Theme.Panel;
        public override Color ToolStripGradientMiddle => Theme.Panel;
        public override Color ToolStripGradientEnd => Theme.Panel;
        public override Color MenuItemSelected => Theme.Panel3;
        public override Color ButtonSelectedHighlight => Theme.Panel3;
        public override Color ButtonSelectedBorder => Theme.Border;
        public override Color SeparatorDark => Theme.Border;
        public override Color SeparatorLight => Theme.Border;
    }
}
