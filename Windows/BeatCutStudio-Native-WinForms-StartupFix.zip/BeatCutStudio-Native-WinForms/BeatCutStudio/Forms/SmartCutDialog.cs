using BeatCutStudio.Infrastructure;
using BeatCutStudio.Models;

namespace BeatCutStudio.Forms;

public sealed class SmartCutDialog : Form
{
    private readonly ComboBox _style = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly NumericUpDown _bpm = new() { Minimum = 40, Maximum = 240, DecimalPlaces = 1, Value = 120 };
    private readonly NumericUpDown _beats = new() { Minimum = 1, Maximum = 16, Value = 4 };
    private readonly NumericUpDown _duration = new() { Minimum = 1, Maximum = 600, DecimalPlaces = 1, Value = 30 };
    private readonly CheckBox _replace = new() { Text = "Bestehende Videoclips ersetzen", Checked = true, AutoSize = true };

    public SmartCutSettings Settings { get; private set; } = new();

    public SmartCutDialog(double bpm, double suggestedDuration)
    {
        Text = "SmartCut";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(440, 315);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;

        _style.Items.AddRange(["Balanced", "Dynamic", "Cinematic", "Energetic", "Smooth", "Minimal", "Glitch / Tech"]);
        _style.SelectedIndex = 0;
        _bpm.Value = (decimal)Math.Clamp(bpm, 40, 240);
        _duration.Value = (decimal)Math.Clamp(suggestedDuration <= 0 ? 30 : suggestedDuration, 1, 600);

        var table = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(16),
            ColumnCount = 2,
            RowCount = 6
        };
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55));

        AddRow(table, "Stil", _style, 0);
        AddRow(table, "BPM", _bpm, 1);
        AddRow(table, "Beats pro Clip", _beats, 2);
        AddRow(table, "Zieldauer (s)", _duration, 3);
        table.Controls.Add(_replace, 0, 4);
        table.SetColumnSpan(_replace, 2);

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        var ok = new Button { Text = "SmartCut erzeugen", DialogResult = DialogResult.OK, AutoSize = true };
        var cancel = new Button { Text = "Abbrechen", DialogResult = DialogResult.Cancel, AutoSize = true };
        buttons.Controls.Add(ok);
        buttons.Controls.Add(cancel);
        table.Controls.Add(buttons, 0, 5);
        table.SetColumnSpan(buttons, 2);

        Controls.Add(table);
        AcceptButton = ok;
        CancelButton = cancel;

        ok.Click += (_, _) =>
        {
            Settings = new SmartCutSettings
            {
                Style = _style.SelectedItem?.ToString() ?? "Balanced",
                Bpm = (double)_bpm.Value,
                BeatsPerClip = (int)_beats.Value,
                TargetDuration = (double)_duration.Value,
                ReplaceExistingVideoClips = _replace.Checked
            };
        };

        Theme.Apply(this);
    }

    private static void AddRow(TableLayoutPanel table, string label, Control control, int row)
    {
        table.Controls.Add(new Label { Text = label, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, row);
        control.Dock = DockStyle.Fill;
        table.Controls.Add(control, 1, row);
    }
}
