using BeatCutStudio.Infrastructure;

namespace BeatCutStudio.Forms;

public sealed class ProgressDialog : Form
{
    private readonly ProgressBar _bar = new() { Dock = DockStyle.Top, Height = 24 };
    private readonly Label _status = new() { Dock = DockStyle.Fill, AutoEllipsis = true, TextAlign = ContentAlignment.TopLeft };
    private readonly Button _cancel = new() { Text = "Abbrechen", Dock = DockStyle.Bottom, Height = 34 };

    public CancellationTokenSource Cancellation { get; } = new();

    public ProgressDialog(string title)
    {
        Text = title;
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(560, 160);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ControlBox = false;

        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16) };
        panel.Controls.Add(_status);
        panel.Controls.Add(_bar);
        panel.Controls.Add(_cancel);
        Controls.Add(panel);

        _cancel.Click += (_, _) =>
        {
            _cancel.Enabled = false;
            _cancel.Text = "Wird abgebrochen...";
            Cancellation.Cancel();
        };

        Theme.Apply(this);
    }

    public IProgress<int> CreateProgress() => new Progress<int>(value => _bar.Value = Math.Clamp(value, 0, 100));
    public IProgress<string> CreateLog() => new Progress<string>(value => _status.Text = value);
}
