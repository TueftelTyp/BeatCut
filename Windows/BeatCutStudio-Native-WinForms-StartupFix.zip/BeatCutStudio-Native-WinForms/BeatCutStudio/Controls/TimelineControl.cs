using BeatCutStudio.Infrastructure;
using BeatCutStudio.Models;

namespace BeatCutStudio.Controls;

public sealed class TimelineControl : Control
{
    private const int HeaderWidth = 165;
    private const int RulerHeight = 26;
    private const int RowHeight = 48;
    private const int MinClipWidth = 18;

    private enum DragMode { None, Move, ResizeLeft, ResizeRight, Playhead }

    private BeatCutProject? _project;
    private readonly HashSet<Guid> _selected = [];
    private DragMode _dragMode;
    private Point _dragStart;
    private Dictionary<Guid, (double Start, double Duration, double SourceStart)> _dragSnapshot = [];
    private Guid? _primaryClipId;
    private double _pixelsPerSecond = 80;
    private double _playheadSeconds;

    public event EventHandler? SelectionChanged;
    public event EventHandler? EditCommitted;
    public event EventHandler? PlayheadChanged;
    public event EventHandler<AssetDroppedEventArgs>? AssetDropped;

    public BeatCutProject? Project
    {
        get => _project;
        set
        {
            _project = value;
            _selected.Clear();
            _primaryClipId = null;
            Invalidate();
            UpdateScrollSize();
        }
    }

    public double PixelsPerSecond
    {
        get => _pixelsPerSecond;
        set
        {
            _pixelsPerSecond = Math.Clamp(value, 20, 300);
            UpdateScrollSize();
            Invalidate();
        }
    }

    public double PlayheadSeconds
    {
        get => _playheadSeconds;
        set
        {
            _playheadSeconds = Math.Max(0, value);
            Invalidate();
        }
    }

    public IReadOnlyCollection<Guid> SelectedClipIds => _selected;

    public TimelineClip? PrimaryClip => _project?.Clips.FirstOrDefault(c => c.Id == _primaryClipId);

    public TimelineControl()
    {
        DoubleBuffered = true;
        BackColor = Theme.Background;
        ForeColor = Theme.Text;
        AllowDrop = true;
        SetStyle(ControlStyles.ResizeRedraw, true);
        MinimumSize = new Size(200, 180);

        DragEnter += OnDragEnter;
        DragDrop += OnDragDrop;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics;
        g.Clear(Theme.Background);

        if (_project is null) return;

        using var rulerBrush = new SolidBrush(Theme.Panel2);
        using var headerBrush = new SolidBrush(Theme.Panel);
        using var gridPen = new Pen(Theme.Border);
        using var textBrush = new SolidBrush(Theme.Muted);
        using var selectedPen = new Pen(Color.White, 2);

        g.FillRectangle(rulerBrush, 0, 0, Width, RulerHeight);
        g.DrawLine(gridPen, 0, RulerHeight - 1, Width, RulerHeight - 1);

        var duration = Math.Max(10, _project.DurationLimitSeconds ?? _project.ContentDuration + 5);
        var step = PixelsPerSecond >= 120 ? 1 : PixelsPerSecond >= 55 ? 2 : 5;
        for (double t = 0; t <= duration + step; t += step)
        {
            var x = HeaderWidth + (float)(t * PixelsPerSecond) - AutoScrollOffsetX();
            if (x < HeaderWidth || x > Width) continue;
            g.DrawLine(gridPen, x, RulerHeight - 8, x, Height);
            g.DrawString(FormatTime(t), Font, textBrush, x + 3, 4);
        }

        for (var row = 0; row < _project.Tracks.Count; row++)
        {
            var track = _project.Tracks[row];
            var y = RulerHeight + row * RowHeight - AutoScrollOffsetY();
            if (y + RowHeight < RulerHeight || y > Height) continue;

            var rowBack = row % 2 == 0 ? Theme.Panel2 : Color.FromArgb(20, 22, 29);
            using var rowBrush = new SolidBrush(rowBack);
            g.FillRectangle(rowBrush, HeaderWidth, y, Width - HeaderWidth, RowHeight);
            g.FillRectangle(headerBrush, 0, y, HeaderWidth, RowHeight);
            g.DrawLine(gridPen, 0, y + RowHeight - 1, Width, y + RowHeight - 1);
            g.DrawLine(gridPen, HeaderWidth - 1, y, HeaderWidth - 1, y + RowHeight);

            using var trackTextBrush = new SolidBrush(track.Muted ? Theme.Muted : Theme.Text);
            g.DrawString(track.Name, Font, trackTextBrush, 9, y + 15);

            var trackClips = _project.Clips.Where(c => c.TrackId == track.Id);
            foreach (var clip in trackClips)
            {
                var rect = ClipRectangle(clip, row);
                if (!rect.IntersectsWith(new Rectangle(HeaderWidth, RulerHeight, Width - HeaderWidth, Height - RulerHeight)))
                    continue;

                var color = track.Type switch
                {
                    TrackType.Video => Color.FromArgb(67, 59, 142),
                    TrackType.OriginalAudio => Color.FromArgb(33, 83, 71),
                    TrackType.Music => Color.FromArgb(28, 102, 76),
                    TrackType.Text => Color.FromArgb(114, 70, 90),
                    TrackType.Effect => Color.FromArgb(108, 85, 31),
                    TrackType.Transition => Color.FromArgb(23, 97, 122),
                    _ => Color.FromArgb(80, 70, 80)
                };

                using var clipBrush = new SolidBrush(color);
                using var clipBorder = new Pen(ControlPaint.Light(color), 1);
                g.FillRectangle(clipBrush, rect);
                g.DrawRectangle(clipBorder, rect);

                var asset = _project.FindAsset(clip.AssetId);
                var label = asset?.Name ?? "Clip";
                using var clipText = new SolidBrush(Color.White);
                var textRect = Rectangle.Inflate(rect, -7, -5);
                g.DrawString(label, Font, clipText, textRect);

                if (_selected.Contains(clip.Id))
                    g.DrawRectangle(selectedPen, Rectangle.Inflate(rect, -1, -1));

                using var handleBrush = new SolidBrush(Color.FromArgb(170, 255, 255, 255));
                g.FillRectangle(handleBrush, rect.Left + 3, rect.Top + 8, 2, rect.Height - 16);
                g.FillRectangle(handleBrush, rect.Right - 5, rect.Top + 8, 2, rect.Height - 16);
            }
        }

        if (_project.DurationLimitSeconds is { } limit)
        {
            var x = HeaderWidth + (float)(limit * PixelsPerSecond) - AutoScrollOffsetX();
            using var limitPen = new Pen(Theme.Danger, 2);
            g.DrawLine(limitPen, x, 0, x, Height);
            using var limitBrush = new SolidBrush(Theme.Danger);
            g.DrawString("LIMIT", Font, limitBrush, x + 4, 3);
        }

        var playheadX = HeaderWidth + (float)(PlayheadSeconds * PixelsPerSecond) - AutoScrollOffsetX();
        using var playheadPen = new Pen(Color.White, 2);
        g.DrawLine(playheadPen, playheadX, 0, playheadX, Height);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (_project is null || e.Button != MouseButtons.Left) return;

        Focus();
        _dragStart = e.Location;

        var playheadX = HeaderWidth + (float)(PlayheadSeconds * PixelsPerSecond) - AutoScrollOffsetX();
        if (Math.Abs(e.X - playheadX) <= 5)
        {
            _dragMode = DragMode.Playhead;
            return;
        }

        var row = RowAt(e.Y);
        if (row < 0 || row >= _project.Tracks.Count)
        {
            SetPlayheadFromX(e.X);
            return;
        }

        var track = _project.Tracks[row];
        if (e.X < HeaderWidth)
        {
            var ids = _project.Clips.Where(c => c.TrackId == track.Id).Select(c => c.Id).ToList();
            if ((ModifierKeys & Keys.Control) == 0)
                _selected.Clear();
            foreach (var id in ids)
                _selected.Add(id);
            _primaryClipId = ids.LastOrDefault();
            SelectionChanged?.Invoke(this, EventArgs.Empty);
            Invalidate();
            return;
        }

        var hit = HitTestClip(e.Location, row);
        if (hit is null)
        {
            if ((ModifierKeys & Keys.Control) == 0)
                _selected.Clear();
            _primaryClipId = null;
            SelectionChanged?.Invoke(this, EventArgs.Empty);
            SetPlayheadFromX(e.X);
            Invalidate();
            return;
        }

        if ((ModifierKeys & Keys.Control) != 0)
        {
            if (!_selected.Add(hit.Id))
                _selected.Remove(hit.Id);
        }
        else if (!_selected.Contains(hit.Id))
        {
            _selected.Clear();
            _selected.Add(hit.Id);
        }

        _primaryClipId = hit.Id;
        SelectionChanged?.Invoke(this, EventArgs.Empty);

        var rect = ClipRectangle(hit, row);
        if (_project.FindTrack(hit.TrackId)?.Locked == true)
        {
            _dragMode = DragMode.None;
            Invalidate();
            return;
        }

        _dragMode = e.X - rect.Left <= 8
            ? DragMode.ResizeLeft
            : rect.Right - e.X <= 8
                ? DragMode.ResizeRight
                : DragMode.Move;

        _dragSnapshot = _project.Clips
            .Where(c => _selected.Contains(c.Id))
            .ToDictionary(c => c.Id, c => (c.Start, c.Duration, c.SourceStart));

        Capture = true;
        Invalidate();
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (_project is null) return;

        if (_dragMode == DragMode.Playhead && e.Button == MouseButtons.Left)
        {
            SetPlayheadFromX(e.X);
            return;
        }

        if (e.Button != MouseButtons.Left || _dragMode == DragMode.None || _dragSnapshot.Count == 0)
            return;

        var delta = (e.X - _dragStart.X) / PixelsPerSecond;
        const double minDuration = 0.1;

        foreach (var clip in _project.Clips.Where(c => _dragSnapshot.ContainsKey(c.Id)))
        {
            var original = _dragSnapshot[clip.Id];
            switch (_dragMode)
            {
                case DragMode.Move:
                    clip.Start = Math.Max(0, original.Start + delta);
                    break;
                case DragMode.ResizeLeft:
                {
                    var newStart = Math.Max(0, original.Start + delta);
                    var consumed = newStart - original.Start;
                    var newDuration = original.Duration - consumed;
                    if (newDuration >= minDuration)
                    {
                        clip.Start = newStart;
                        clip.Duration = newDuration;
                        clip.SourceStart = Math.Max(0, original.SourceStart + consumed);
                    }
                    break;
                }
                case DragMode.ResizeRight:
                    clip.Duration = Math.Max(minDuration, original.Duration + delta);
                    break;
            }
        }

        Invalidate();
        UpdateScrollSize();
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (_dragMode is DragMode.Move or DragMode.ResizeLeft or DragMode.ResizeRight)
            EditCommitted?.Invoke(this, EventArgs.Empty);

        _dragMode = DragMode.None;
        _dragSnapshot.Clear();
        Capture = false;
    }

    protected override void OnMouseWheel(MouseEventArgs e)
    {
        if ((ModifierKeys & Keys.Control) != 0)
        {
            PixelsPerSecond += e.Delta > 0 ? 10 : -10;
            return;
        }
        base.OnMouseWheel(e);
    }

    public void ClearSelection()
    {
        _selected.Clear();
        _primaryClipId = null;
        SelectionChanged?.Invoke(this, EventArgs.Empty);
        Invalidate();
    }

    public void SelectClip(Guid clipId)
    {
        _selected.Clear();
        _selected.Add(clipId);
        _primaryClipId = clipId;
        SelectionChanged?.Invoke(this, EventArgs.Empty);
        Invalidate();
    }

    private TimelineClip? HitTestClip(Point point, int row)
    {
        if (_project is null) return null;
        return _project.Clips
            .Where(c => c.TrackId == _project.Tracks[row].Id)
            .Reverse<TimelineClip>()
            .FirstOrDefault(c => ClipRectangle(c, row).Contains(point));
    }

    private Rectangle ClipRectangle(TimelineClip clip, int row)
    {
        var x = HeaderWidth + (int)Math.Round(clip.Start * PixelsPerSecond) - AutoScrollOffsetX();
        var y = RulerHeight + row * RowHeight + 5 - AutoScrollOffsetY();
        var w = Math.Max(MinClipWidth, (int)Math.Round(clip.Duration * PixelsPerSecond));
        return new Rectangle(x, y, w, RowHeight - 10);
    }

    private int RowAt(int y) => (y + AutoScrollOffsetY() - RulerHeight) / RowHeight;

    private void SetPlayheadFromX(int x)
    {
        var time = (x + AutoScrollOffsetX() - HeaderWidth) / PixelsPerSecond;
        PlayheadSeconds = Math.Max(0, time);
        PlayheadChanged?.Invoke(this, EventArgs.Empty);
    }

    private void OnDragEnter(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetDataPresent("BeatCutAssetId") == true)
            e.Effect = DragDropEffects.Copy;
    }

    private void OnDragDrop(object? sender, DragEventArgs e)
    {
        if (_project is null || e.Data?.GetData("BeatCutAssetId") is not string idText || !Guid.TryParse(idText, out var assetId))
            return;

        var client = PointToClient(new Point(e.X, e.Y));
        var row = Math.Clamp(RowAt(client.Y), 0, Math.Max(0, _project.Tracks.Count - 1));
        var time = Math.Max(0, (client.X + AutoScrollOffsetX() - HeaderWidth) / PixelsPerSecond);
        AssetDropped?.Invoke(this, new AssetDroppedEventArgs(assetId, _project.Tracks[row].Id, time));
    }

    private int AutoScrollOffsetX() => Parent is ScrollableControl sc ? -sc.AutoScrollPosition.X : 0;
    private int AutoScrollOffsetY() => Parent is ScrollableControl sc ? -sc.AutoScrollPosition.Y : 0;

    private void UpdateScrollSize()
    {
        if (_project is null || Parent is not ScrollableControl scroll) return;
        var duration = Math.Max(15, _project.DurationLimitSeconds ?? _project.ContentDuration + 10);
        scroll.AutoScrollMinSize = new Size(HeaderWidth + (int)(duration * PixelsPerSecond) + 120,
            RulerHeight + _project.Tracks.Count * RowHeight + 10);
    }

    private static string FormatTime(double seconds)
    {
        var value = TimeSpan.FromSeconds(Math.Max(0, seconds));
        return value.TotalHours >= 1 ? value.ToString(@"h\:mm\:ss") : value.ToString(@"m\:ss");
    }
}

public sealed class AssetDroppedEventArgs : EventArgs
{
    public Guid AssetId { get; }
    public Guid TrackId { get; }
    public double Time { get; }

    public AssetDroppedEventArgs(Guid assetId, Guid trackId, double time)
    {
        AssetId = assetId;
        TrackId = trackId;
        Time = time;
    }
}
