using BeatCutStudio.Forms;
using System.Text;

namespace BeatCutStudio;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, e) => ShowFatalError(e.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
        {
            if (e.ExceptionObject is Exception ex)
                ShowFatalError(ex);
        };

        try
        {
            Application.Run(new MainForm());
        }
        catch (Exception ex)
        {
            ShowFatalError(ex);
        }
    }

    private static void ShowFatalError(Exception ex)
    {
        try
        {
            var folder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "BeatCutStudio");
            Directory.CreateDirectory(folder);
            var logPath = Path.Combine(folder, "startup-error.log");
            File.AppendAllText(
                logPath,
                $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}]\r\n{ex}\r\n\r\n",
                Encoding.UTF8);

            MessageBox.Show(
                "BeatCut Studio konnte einen Programmfehler nicht abfangen.\n\n" +
                ex.Message +
                "\n\nFehlerprotokoll:\n" + logPath,
                "BeatCut Studio",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
        catch
        {
            MessageBox.Show(
                ex.ToString(),
                "BeatCut Studio",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
