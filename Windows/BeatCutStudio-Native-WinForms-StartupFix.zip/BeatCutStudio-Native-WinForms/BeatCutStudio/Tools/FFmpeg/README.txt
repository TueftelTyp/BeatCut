BeatCut Studio verwendet für den nativen MP4-Export ffmpeg.exe und ffprobe.exe.

Lege beide Dateien direkt in diesen Ordner:

BeatCutStudio\Tools\FFmpeg\ffmpeg.exe
BeatCutStudio\Tools\FFmpeg\ffprobe.exe

Alternativ dürfen FFmpeg und FFprobe systemweit in PATH installiert sein.

Die Binaries sind absichtlich nicht in diesem Quellcode-ZIP enthalten.
Bitte verwende einen offiziellen bzw. von dir geprüften Windows-Build von FFmpeg und beachte dessen Lizenzbedingungen.
