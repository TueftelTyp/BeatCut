namespace BeatCutStudio.Models;

public sealed class ExportSettings
{
    public string OutputPath { get; set; } = string.Empty;
    public int Width { get; set; } = 1080;
    public int Height { get; set; } = 1920;
    public int Fps { get; set; } = 30;
    public int Crf { get; set; } = 20;
    public string Preset { get; set; } = "veryfast";
    public bool IncludeMusic { get; set; } = true;
}
