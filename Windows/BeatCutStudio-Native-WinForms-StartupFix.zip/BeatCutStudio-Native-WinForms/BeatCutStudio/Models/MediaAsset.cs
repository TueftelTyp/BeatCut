using System.ComponentModel;

namespace BeatCutStudio.Models;

public sealed class MediaAsset
{
    [Browsable(false)]
    public Guid Id { get; set; } = Guid.NewGuid();

    [Category("Datei"), DisplayName("Name")]
    public string Name { get; set; } = string.Empty;

    [Category("Datei"), DisplayName("Pfad"), ReadOnly(true)]
    public string FilePath { get; set; } = string.Empty;

    [Category("Medien"), DisplayName("Typ"), ReadOnly(true)]
    public MediaAssetType Type { get; set; }

    [Category("Medien"), DisplayName("Dauer (s)"), ReadOnly(true)]
    public double Duration { get; set; }

    [Category("Medien"), DisplayName("Breite"), ReadOnly(true)]
    public int Width { get; set; }

    [Category("Medien"), DisplayName("Höhe"), ReadOnly(true)]
    public int Height { get; set; }

    [Category("Medien"), DisplayName("Audio vorhanden"), ReadOnly(true)]
    public bool HasAudio { get; set; }

    public override string ToString() => Name;
}
