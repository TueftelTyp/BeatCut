namespace BeatCutStudio.Models;

public sealed class BeatCutProject
{
    public string Name { get; set; } = "Mein Video";
    public int Width { get; set; } = 1080;
    public int Height { get; set; } = 1920;
    public int FramesPerSecond { get; set; } = 30;
    public double? DurationLimitSeconds { get; set; } = 60;
    public double Bpm { get; set; } = 120;

    public List<MediaAsset> Assets { get; set; } = [];
    public List<TimelineTrack> Tracks { get; set; } = [];
    public List<TimelineClip> Clips { get; set; } = [];

    public double ContentDuration => Clips.Count == 0 ? 0 : Clips.Max(c => c.End);

    public double ProjectDuration
    {
        get
        {
            var duration = ContentDuration;
            if (DurationLimitSeconds is { } limit)
                duration = Math.Min(duration, limit);
            return Math.Max(0, duration);
        }
    }

    public MediaAsset? FindAsset(Guid id) => Assets.FirstOrDefault(a => a.Id == id);
    public TimelineTrack? FindTrack(Guid id) => Tracks.FirstOrDefault(t => t.Id == id);

    public static BeatCutProject CreateDefault()
    {
        var project = new BeatCutProject();
        project.Tracks.AddRange([
            new TimelineTrack { Name = "V1 · Video", Type = TrackType.Video },
            new TimelineTrack { Name = "Originalton", Type = TrackType.OriginalAudio },
            new TimelineTrack { Name = "Text", Type = TrackType.Text },
            new TimelineTrack { Name = "FX", Type = TrackType.Effect },
            new TimelineTrack { Name = "Übergänge", Type = TrackType.Transition },
            new TimelineTrack { Name = "Audio FX", Type = TrackType.AudioEffect },
            new TimelineTrack { Name = "Musik", Type = TrackType.Music }
        ]);
        return project;
    }
}
