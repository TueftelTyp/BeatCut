namespace BeatCutStudio.Models;

public enum MediaAssetType
{
    Video,
    Image,
    Audio
}

public enum TrackType
{
    Video,
    OriginalAudio,
    Text,
    Effect,
    Transition,
    AudioEffect,
    Music
}
