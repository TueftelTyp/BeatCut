namespace BeatCutStudio.Models;

public sealed class TimelineTrack
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "Spur";
    public TrackType Type { get; set; }
    public bool Visible { get; set; } = true;
    public bool Muted { get; set; }
    public bool Locked { get; set; }
    public bool Collapsed { get; set; }
}
