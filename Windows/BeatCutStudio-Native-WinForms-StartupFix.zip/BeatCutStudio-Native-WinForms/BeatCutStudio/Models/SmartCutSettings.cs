namespace BeatCutStudio.Models;

public sealed class SmartCutSettings
{
    public string Style { get; set; } = "Balanced";
    public double Bpm { get; set; } = 120;
    public int BeatsPerClip { get; set; } = 4;
    public double TargetDuration { get; set; } = 30;
    public bool ReplaceExistingVideoClips { get; set; } = true;
}
