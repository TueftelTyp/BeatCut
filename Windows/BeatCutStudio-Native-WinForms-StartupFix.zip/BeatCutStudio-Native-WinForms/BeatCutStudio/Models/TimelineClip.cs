using System.ComponentModel;

namespace BeatCutStudio.Models;

public sealed class TimelineClip
{
    [Browsable(false)]
    public Guid Id { get; set; } = Guid.NewGuid();

    [Browsable(false)]
    public Guid TrackId { get; set; }

    [Browsable(false)]
    public Guid AssetId { get; set; }

    [Category("Timeline"), DisplayName("Start (s)")]
    public double Start { get; set; }

    [Category("Timeline"), DisplayName("Dauer (s)")]
    public double Duration { get; set; } = 3;

    [Category("Quelle"), DisplayName("Quellstart (s)")]
    public double SourceStart { get; set; }

    [Category("Audio"), DisplayName("Lautstärke")]
    public double Volume { get; set; } = 1.0;

    [Category("Audio"), DisplayName("Stumm")]
    public bool Muted { get; set; }

    [Category("Audio"), DisplayName("Fade In (s)")]
    public double FadeIn { get; set; }

    [Category("Audio"), DisplayName("Fade Out (s)")]
    public double FadeOut { get; set; }

    [Category("Bild"), DisplayName("Deckkraft")]
    public double Opacity { get; set; } = 1.0;

    [Category("Bild"), DisplayName("Skalierung")]
    public double Scale { get; set; } = 1.0;

    [Category("Bild"), DisplayName("Rotation")]
    public double Rotation { get; set; }

    public double End => Start + Duration;
}
