# Changelog

## 0.2.2 – Startup-/Oberflächen-Fix

- SplitContainer-Größen werden erst nach dem Anzeigen des Hauptfensters gesetzt.
- Verhindert Startabbrüche durch ungültige `SplitterDistance`/Mindestgrößen während der Konstruktion.
- LibVLC wird erst nach dem Anzeigen der WinForms-Oberfläche initialisiert.
- Die Oberfläche bleibt auch dann geöffnet, wenn LibVLC nicht initialisiert werden kann.
- Startfehler werden als Meldung angezeigt und unter `%LOCALAPPDATA%\BeatCutStudio\startup-error.log` protokolliert.


## 0.2.0 Native Alpha

- vollständiger Wechsel auf native Windows Forms
- WebView2/HTML entfernt
- LibVLCSharp-Vorschau
- native Timeline-Control
- Medienimport und Drag & Drop
- Trim/Move/Split/Copy/Delete
- Undo/Redo
- Projekt speichern/öffnen
- SmartCut-Grundfunktion
- nativer FFmpeg-MP4-Export
- Musik-Mixing
- direkte Windows-Dateiausgabe
## 0.1.1 – Compile-Fix

- `TrackType`-Namenskonflikt zwischen BeatCut-Modell und LibVLCSharp über einen expliziten Alias behoben.
- `Theme.Panel`/`Panel`-Namenskonflikt im Pattern Matching behoben; WinForms-`Panel` wird jetzt vollqualifiziert verwendet.

