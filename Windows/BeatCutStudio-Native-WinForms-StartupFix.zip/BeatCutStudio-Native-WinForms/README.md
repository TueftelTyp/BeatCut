# BeatCut Studio Native – WinForms

Dies ist eine **echte lokale Windows-Forms-Neuentwicklung** von BeatCut Studio. Es wird **kein WebView2, kein HTML und kein Browser-Download** verwendet.

## Technik

- Visual Studio 2022
- .NET 8 / Windows Forms
- LibVLCSharp + LibVLC für lokale Video-/Audio-Vorschau
- natives FFmpeg/FFprobe für MP4-Export
- eigene WinForms-Timeline
- JSON-basierte `.beatcut`-Projektdateien

## Bereits umgesetzt

- native WinForms-Oberfläche im BeatCut-Dark-Design
- Medienbrowser für Bilder, Videos und Musik
- Drag & Drop vom Medienbrowser in die Timeline
- Doppelklick auf Medien fügt sie am Playhead ein
- eigene mehrspurige Timeline
- Video-, Originalton-, Text-, FX-, Übergangs-, Audio-FX- und Musikspur als native Track-Struktur
- Clip-Auswahl und Mehrfachauswahl mit `Strg`
- Klick auf Spurname markiert die komplette Spur
- Clips verschieben
- Clips links/rechts trimmen
- Playhead per Maus verschieben
- Timeline-Zoom mit `Strg + Mausrad` oder Zoomfeld
- Auswahl aufheben
- Clip teilen
- Auswahl löschen
- Auswahl an den Playhead kopieren
- Undo / Redo
- native Video-/Audio-Vorschau über LibVLC
- Bildvorschau
- Musik kann parallel zur Video-Vorschau laufen
- Clip-Lautstärke und Stummschaltung über Eigenschaften
- Fade-In/Fade-Out-Werte für Audio
- Projekt speichern / öffnen (`.beatcut`)
- SmartCut-Grundfunktion mit Stil, BPM, Beats pro Clip und Zieldauer
- nativer MP4-Export direkt in eine gewählte Windows-Datei
- H.264 / AAC / YUV420P / konstante Framerate / Fast Start
- Video-Originalton wird exportiert
- Musikspur wird beim Export eingemischt
- Bilder werden als echte Videosegmente exportiert
- Timeline-Lücken werden als schwarze Segmente exportiert
- Export-Abbruch und Fortschrittsfenster
- Release-Publish-Skripte

## Noch nicht 1:1 aus der Webversion portiert

Die native Umsetzung ist eine neue Codebasis. Folgende komplexe Bereiche sind vorbereitet, aber noch nicht vollständig als nativer Renderer umgesetzt:

- Text-Rendering im Export
- Videoeffekte im Export
- Übergangsrenderer im Export
- Audio-FX-System mit Tape-Stop/Speed-Effekten
- automatische BPM-Erkennung aus der Musikdatei
- visuelle Szenenanalyse
- mehrere gleichzeitig übereinander compositete Videospuren
- Waveform-/Pitch-Zeichnung
- vollständig paketierte `.beatcut`-Datei inklusive Medienblobs

Die Timeline enthält die Track-Typen dafür bereits. Die aktuelle Export-Pipeline rendert die erste Videospur sequenziell und mischt die Musikspur ein.

## Voraussetzungen

1. **Visual Studio 2022**
2. Workload **.NET-Desktopentwicklung**
3. .NET 8 SDK
4. Internetzugriff beim ersten NuGet-Restore für LibVLCSharp/LibVLC
5. `ffmpeg.exe` und `ffprobe.exe`

## FFmpeg einrichten

Lege die beiden Dateien hier ab:

```text
BeatCutStudio\Tools\FFmpeg\ffmpeg.exe
BeatCutStudio\Tools\FFmpeg\ffprobe.exe
```

Alternativ können beide Programme in der Windows-PATH-Variable vorhanden sein.

## Start in Visual Studio

1. `BeatCutStudio.sln` öffnen.
2. NuGet-Pakete wiederherstellen lassen.
3. FFmpeg wie oben beschrieben ablegen.
4. `F5` drücken.

## Release bauen

Doppelklick auf:

```text
build-release.bat
```

oder in PowerShell:

```powershell
./build-release.ps1
```

Die Ausgabe landet in:

```text
publish\win-x64\
```

## Tastatur

- `Strg + Z` – Rückgängig
- `Strg + Y` – Wiederholen
- `Strg + Shift + Z` – Wiederholen
- `Strg + D` – Auswahl an Playhead kopieren
- `Entf` – Auswahl löschen
- `Leertaste` – Wiedergabe/Pause

## MP4-Export

Der Export schreibt direkt auf die Festplatte. Es gibt keinen Browser-Download und kein MediaRecorder/WebM-Zwischenformat.

Für jeden Clip wird zunächst ein normalisiertes H.264/AAC-Segment erstellt. Anschließend werden die Segmente zusammengefügt und die Musikspur wird optional eingemischt. Das vermeidet die problematischen Browser-Zeitstempel der früheren Webversion.
