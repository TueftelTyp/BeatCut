@echo off
setlocal
cd /d "%~dp0"

where dotnet >nul 2>nul
if errorlevel 1 (
    echo FEHLER: .NET SDK wurde nicht gefunden.
    echo Installiere Visual Studio 2022 mit .NET-Desktopentwicklung und .NET 8.
    pause
    exit /b 1
)

echo [1/2] NuGet/Restore...
dotnet restore BeatCutStudio.sln
if errorlevel 1 (
    echo Restore fehlgeschlagen.
    pause
    exit /b 1
)

if exist "publish\win-x64" rmdir /s /q "publish\win-x64"

echo [2/2] Release Publish...
dotnet publish BeatCutStudio\BeatCutStudio.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=false -o "publish\win-x64"
if errorlevel 1 (
    echo Build fehlgeschlagen.
    pause
    exit /b 1
)

echo.
echo Fertig: %cd%\publish\win-x64
start "" "%cd%\publish\win-x64"
pause
