using System.Windows;

namespace BeatCutStudio;

public partial class App : Application
{
}
