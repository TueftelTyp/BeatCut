using Microsoft.Web.WebView2.Core;
using System;
using System.Diagnostics;
using System.IO;
using System.Windows;

namespace BeatCutStudio;

public partial class MainWindow : Window
{
    private const string VirtualHost = "beatcut.local";

    public MainWindow()
    {
        InitializeComponent();
        Loaded += MainWindow_Loaded;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            string userDataFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "BeatCutStudio",
                "WebView2");

            Directory.CreateDirectory(userDataFolder);

            CoreWebView2Environment environment =
                await CoreWebView2Environment.CreateAsync(userDataFolder: userDataFolder);

            await EditorWebView.EnsureCoreWebView2Async(environment);

            ConfigureWebView();

            string webFolder = Path.Combine(AppContext.BaseDirectory, "Web");
            string indexPath = Path.Combine(webFolder, "index.html");

            if (!File.Exists(indexPath))
            {
                MessageBox.Show(
                    $"Die BeatCut-Oberfläche wurde nicht gefunden:\n\n{indexPath}",
                    "BeatCut Studio",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);

                Close();
                return;
            }

            EditorWebView.CoreWebView2.SetVirtualHostNameToFolderMapping(
                VirtualHost,
                webFolder,
                CoreWebView2HostResourceAccessKind.Allow);

            EditorWebView.Source = new Uri($"https://{VirtualHost}/index.html");
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "BeatCut Studio konnte nicht gestartet werden.\n\n" + ex.Message,
                "BeatCut Studio",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void ConfigureWebView()
    {
        CoreWebView2Settings settings = EditorWebView.CoreWebView2.Settings;

        settings.IsScriptEnabled = true;
        settings.AreDefaultContextMenusEnabled = true;
        settings.AreDevToolsEnabled = true;
        settings.IsZoomControlEnabled = true;
        settings.AreBrowserAcceleratorKeysEnabled = true;
        settings.IsStatusBarEnabled = false;

        EditorWebView.CoreWebView2.NewWindowRequested += (_, e) =>
        {
            if (Uri.TryCreate(e.Uri, UriKind.Absolute, out Uri? uri) &&
                !string.Equals(uri.Host, VirtualHost, StringComparison.OrdinalIgnoreCase))
            {
                try
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = uri.ToString(),
                        UseShellExecute = true
                    });
                }
                catch
                {
                }

                e.Handled = true;
            }
        };
    }
}
