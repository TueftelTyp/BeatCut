$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

dotnet restore ".\BeatCutStudio.sln"
if ($LASTEXITCODE -ne 0) { throw "Restore fehlgeschlagen." }

$publishDir = Join-Path $root "publish\win-x64"
if (Test-Path $publishDir) { Remove-Item $publishDir -Recurse -Force }

dotnet publish ".\BeatCutStudio\BeatCutStudio.csproj" `
  -c Release `
  -r win-x64 `
  --self-contained true `
  -p:PublishSingleFile=false `
  -o $publishDir

if ($LASTEXITCODE -ne 0) { throw "Build fehlgeschlagen." }

Write-Host "Fertig: $publishDir"
