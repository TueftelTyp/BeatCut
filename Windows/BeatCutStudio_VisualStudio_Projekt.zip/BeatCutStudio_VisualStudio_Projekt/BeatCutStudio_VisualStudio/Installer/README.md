# Installer

Die Projektmappe erzeugt zunächst einen Windows-Publish-Ordner.

Für einen klassischen Setup-Installer in Visual Studio:

1. `Erweiterungen > Erweiterungen verwalten`
2. `Microsoft Visual Studio Installer Projects` installieren
3. Visual Studio neu starten
4. Der Lösung ein `Setup Project` hinzufügen
5. Den Inhalt von `publish/win-x64/` als Application Folder übernehmen
6. Desktop-/Startmenü-Verknüpfung hinzufügen
7. Setup-Projekt in `Release` bauen

Alternativ kann später ein MSIX-Paket ergänzt werden.

Vorher den Release-Ordner mit `build-release.bat` oder `build-release.ps1` erzeugen.
