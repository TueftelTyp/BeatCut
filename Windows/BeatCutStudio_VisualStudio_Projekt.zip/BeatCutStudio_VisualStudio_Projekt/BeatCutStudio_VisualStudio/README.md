# BeatCut Studio – Visual-Studio-Projekt

Windows-Grundstruktur für BeatCut Studio mit **Visual Studio 2022**, **.NET 8**, **WPF** und **Microsoft WebView2**.

## Start

1. ZIP entpacken.
2. `BeatCutStudio.sln` in Visual Studio 2022 öffnen.
3. Falls nötig den Workload **.NET-Desktopentwicklung** installieren.
4. NuGet-Pakete wiederherstellen.
5. Deine aktuelle vollständige BeatCut-Datei nach `BeatCutStudio/Web/index.html` kopieren und die vorhandene Platzhalterdatei ersetzen.
6. `F5` drücken.

Die Weboberfläche wird über `https://beatcut.local/index.html` geladen, damit Module und lokale Ressourcen zuverlässiger funktionieren als über `file://`.

## Release-Build

`build-release.bat` doppelklicken oder in PowerShell `./build-release.ps1` ausführen.

Ausgabe: `publish/win-x64/`

## Wichtig

Die enthaltene `Web/index.html` ist nur eine Startseite. Deine aktuelle vollständige BeatCut-`index.html` muss dort eingesetzt werden.

Für einen Installer siehe `Installer/README.md`.
