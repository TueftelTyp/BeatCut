# BeatCut Studio – Architektur v0.3.5

## Ziel

Die vollständige große BeatCut-Weboberfläche bleibt erhalten. Die neue Serverarchitektur verschiebt nur Aufgaben aus dem Browser, die dort unzuverlässig oder sicherheitskritisch sind.

```text
Browser
├─ kompletter Editor
├─ Timeline / SmartCut / BPM
├─ Vorschau / Canvas-Komposition
├─ Text / FX / Übergänge
├─ Audio / Originalton / Musik / Audio-FX
├─ IndexedDB + .beatcut
└─ Export-Vorbereitung
       │
       ▼
Node.js HTTP/API
├─ Health/Diagnose
├─ sichere Render-Uploads
├─ Projekt-/Medien-API
├─ SQLite
├─ Renderqueue
└─ native Prozesssteuerung
       │
       ▼
FFmpeg / FFprobe
└─ H.264 + AAC → MP4
```

## Primärer MP4-Pfad

Bei WebCodecs:

```text
Projektzeit t = Frame / FPS
        ↓
aktive Clips exakt suchen/positionieren
        ↓
renderFrame(t)
        ↓
Canvas enthält komplette sichtbare Komposition
        ↓
VideoFrame + VideoEncoder
        ↓
H.264 Annex-B

BeatCut-Audiomix
        ↓
OfflineAudioContext (normaler Pfad)
        ↓
PCM WAV 48 kHz Stereo

Speed/Tape-FX oder Ressourcenlimit
        ↓
Web Audio / MediaRecorder
        ↓
WebM/Opus

H.264 + Audio
        ↓
Server-Upload mit temporären Tokens
        ↓
natives FFmpeg
        ↓
CFR H.264/AAC MP4
```

Der visuelle Renderdurchsatz bestimmt damit nicht mehr die Videodauer.

## Browser-Kompatibilitätsweg

Ohne WebCodecs wird die komplette Canvas-/Audioausgabe in Echtzeit als WebM aufgenommen. Dieses WebM wird nicht mit FFmpeg.wasm verarbeitet, sondern zum Server übertragen und dort nativ normalisiert.

## Datenverzeichnisse

```text
data/
├─ uploads/
├─ thumbs/
├─ renders/
├─ temp/
└─ precomposed/
```

Precomposed-Inputs sind temporäre Exportartefakte und werden nach Abschluss/Abbruch eines Jobs sowie bei Startup/periodischer Wartung entfernt.

## Sicherheitsgrenzen

- Standardbind: 127.0.0.1
- keine Shell bei FFmpeg-Prozessen
- IDs/Pfade validiert
- Größenlimits
- sichere statische Dateiauflösung
- CORS lokal beziehungsweise explizit konfiguriert
- CSP ohne externe Scripts
- externe Google Fonts optional, keine ausführbaren Ressourcen

Für Internetbetrieb ist ein Reverse Proxy mit TLS und Authentifizierung notwendig.

## Vorschau-Stabilität

Die interaktive Vorschau verwendet dekodierte Video-Frames aus `requestVideoFrameCallback`. Wenn ein Decoder gerade seeked oder noch keinen neuen Frame geliefert hat, wird der letzte vollständig zusammengesetzte Previewframe in reduzierter Auflösung gehalten. Effekte/Übergänge werden auf diesem bereits zusammengesetzten Fallback nicht erneut angewendet. Der Export verwendet diesen Preview-Fallback nie.

## Projektarchive

`.beatcut` bleibt ein ZIP-basiertes Projektformat. Medien werden mit ZIP-Methode `STORE` gespeichert, weil MP4, MP3, JPEG und PNG bereits komprimiert sind. Das vermeidet CPU-intensive Rekodierung/DEFLATE-Arbeit. Das vollständige Archiv wird derzeit weiterhin im Browser als Blob erzeugt.


## Projektdatei-Pipeline v0.3.5

Große `.beatcut`-Dateien werden serverseitig aufgebaut. Das Frontend lädt die einzelnen Originalmedien sequenziell in eine temporäre Projektpaket-Sitzung. Der Backend-ZIP-Writer schreibt STORE-Einträge direkt als Stream auf die Festplatte und unterstützt ZIP64. Dadurch entsteht im Browser kein zweiter vollständiger Projekt-Blob. Nach der Finalisierung wird das Archiv über einen normalen HTTP-Download gestreamt.


## SmartCut-Szenenanalyse v0.3.6

Die Szenenanalyse arbeitet clientseitig in zwei Phasen. Eine Grobanalyse tastet das gesamte Video ab; anschließend werden hoch bewertete Zeitbereiche dichter untersucht. Pro Sample werden Helligkeit, Kontrast, Sättigung, Farbwärme, Bewegung und eine lokale Kanten-/Schärfemetrik gespeichert. Die Rohmetriken werden unabhängig von einem Stil gespeichert. Erst beim SmartCut werden sie mit den aktuellen Benutzergewichten gerankt. Dadurch kann ein bereits analysiertes Medium mit einem anderen Profil sofort anders ausgewählt werden.
