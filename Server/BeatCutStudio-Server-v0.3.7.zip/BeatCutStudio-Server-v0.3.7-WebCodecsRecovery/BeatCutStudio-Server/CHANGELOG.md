# Changelog

## 0.3.7 – WebCodecs Inactivity Recovery

- `Codec reclaimed due to inactivity` beendet den MP4-Export nicht mehr sofort.
- WebCodecs-Frames werden frameweise geflusht, bevor der nächste Video-Seek beginnt.
- Freigegebene Encoder werden automatisch neu erstellt; ein Neustart beginnt mit Keyframe.
- Nach dem ersten Reclaim wird bevorzugt ein Softwarecodec verwendet, sofern verfügbar.
- Wiederholte Reclaim-Fehler führen automatisch in den MediaRecorder→Server-FFmpeg-Kompatibilitätsmodus.
- Server-/FFmpeg-Kompatibilität mit aneinandergehängten Annex-B-H.264-Encoder-Sitzungen wird getestet.

## 0.3.6 – Advanced SmartCut Scene Analysis

- Neuer aufklappbarer Bereich „Szenenanalyse & Gewichtung“ im SmartCut-Dialog.
- Frei einstellbare Regler von −100 bis +100 für Bewegung, Kontrast, Sättigung, Schärfe/Details, Helligkeit und Farbwärme.
- Eigene Analysegenauigkeit von 25–100 %.
- Stilabhängige Analyseprofile für Balanced, Dynamic, Cinematic, Energetic, Smooth, Travel, Minimal, Dreamy, Glitch/Tech und Dramatic.
- Zweistufige Grob-/Feinanalyse: zuerst Gesamtvideo abtasten, danach aussichtsreiche Zeitbereiche dichter untersuchen.
- Szenen speichern Rohmetriken; geänderte Gewichte können vorhandene Analysewerte neu ranken, ohne zwangsläufig das Video erneut zu dekodieren.
- SmartCut bewertet nicht nur das Medium, sondern auch konkrete Quellfenster innerhalb des Videos anhand der aktuellen Gewichtung.
- Analysegewichtungen und Genauigkeit werden im Projekt gespeichert und wiederhergestellt; alte Projekte erhalten automatisch das Stilprofil.
- Projektformat auf Version 22 erhöht; Rückwärtskompatibilität bleibt erhalten.

## 0.3.5 – Streaming Project Packages

- `.beatcut`-Projektdateien werden serverseitig gestreamt statt als riesiger Browser-Blob erzeugt.
- Neuer sicherer Projektpaket-Workflow: Sitzung → sequenzielle Datei-Uploads → serverseitiges ZIP → direkter Download.
- ZIP-Writer nutzt STORE und unterstützt ZIP64; große MP4/MP3/JPEG-Dateien werden nicht erneut komprimiert.
- Mehrspur-/Mehrmedien-Projekte umgehen damit Browser-Blob-/RAM-Grenzen.
- Dateigrößen, IDs, Dateinamen, ZIP-Pfade und Gesamtgröße werden validiert.
- Unvollständige Uploads können nicht finalisiert werden.
- Projektpaket-Downloads verwenden sichere Content-Disposition-Dateinamen inklusive UTF-8-Fallback.
- Temporäre Projektpakete werden beim Start bzw. nach Ablauf bereinigt.
- Der bestehende Upload-413-Pfad wurde gegen TCP-Races bei kleinen Größenüberschreitungen gehärtet.
- QA erweitert um 3-Medien-Paket, JSZip/CRC-Kompatibilität, Traversal-Schutz und Streaming-Test mit drei größeren Einträgen.

## 0.3.4 – Preview Reliability / Offline Audio / Fast Project Files

### Behoben

- sporadische schwarze Frames beim ersten Abspielen/Decoder-Seeking durch dekodierten `requestVideoFrameCallback`-Framecache und Last-Good-Preview-Fallback behoben.
- Vorschau-Effekte/Übergänge werden auf einem gehaltenen Fallbackframe nicht erneut angewendet; dadurch keine doppelten/halb initialisierten Effektbilder beim ersten Durchlauf.
- normaler MP4-Audiomix wird über `OfflineAudioContext` als 48-kHz-Stereo-WAV erzeugt und ist damit unabhängig von Tab-Stummschaltung/Browser-Ausgabelautstärke.
- Server akzeptiert WAV als sicheren Precomposed-Audioinput und muxxt ihn zu AAC.
- Speed-/Tape-Audio-FX sowie sehr große/lange Projekte verwenden weiterhin den vorhandenen Echtzeit-Fallback.

### Performance

- `.beatcut`-ZIPs verwenden für bereits komprimierte Medien `STORE` statt DEFLATE.
- `streamFiles: true` reduziert unnötige ZIP-Arbeit; kompakte `project.json` statt Pretty-Print.
- Preview-Fallback wird nur in reduzierter Auflösung gehalten und niemals für den deterministischen Export verwendet.

### Regression-Schutz

- Runtime-Test für schwarzen Video-Frame mit Last-Good-Preview-Fallback.
- WAV-Header/PCM-Größentest.
- echte WAV → AAC-MP4-Integration über natives FFmpeg.
- statischer Test für STORE-Projektarchiv und Offline-Audio-Primärpfad.

## 0.3.3 – Preview Performance

### Optimiert

- Vorschau-Rendering und Medien-Sync auf 30 FPS begrenzt, während der Playhead weiterhin pro Display-Frame aktualisiert wird.
- wiederholte Video-Seeks bei kleinen Driftwerten entfernt; harte Synchronisation erst ab deutlicher Abweichung.
- redundantes Frame-Caching im laufenden Renderpfad entfernt.
- Audio-Zeitintegration besitzt einen O(1)-Fast-Path, solange keine Speed-/Tape-FX im relevanten Bereich aktiv sind.
- Canvas-Kontext nutzt `desynchronized: true`, wenn der Browser dies unterstützt.
- Exportauflösung und deterministischer Server-MP4-Pfad bleiben unverändert.

### Regression-Schutz

- Test für 30-FPS-Throttling bei simulierten 60-Hz-Frames.
- Test, dass Playhead-Updates auch bei übersprungenen Preview-Frames weiterlaufen.
- Test gegen redundante Cache-Copies während laufender Wiedergabe.

## 0.3.2 – SmartCut / Transition / Playback / Playhead Fix

### Behoben

- **Root Cause:** `renderFrame()` prüfte aktive Übergänge mit `time < t.start + t.duration`, obwohl `t` erst als `for (const t of ...)`-Schleifenvariable initialisiert wurde. Das erzeugte eine Temporal-Dead-Zone (`can't access lexical declaration 't' before initialization`).
- SmartCut konnte deshalb nach Analyse/Clip-Erzeugung abbrechen, sobald automatische Übergänge vorhanden waren.
- Derselbe Fehler stoppte den `requestAnimationFrame`-Wiedergabeloop: Ton konnte weiterlaufen, während Video/Canvas und Playhead stehenblieben.
- `setProjectTime()` erreichte nach dem `renderFrame()`-Fehler das Marker-Update nicht; der Playhead wirkte dadurch unbeweglich.
- Übergangsfilter verwendet jetzt korrekt `x.start + x.duration`; Schleifenvariable heißt eindeutig `transition`.
- Zu große Uploads schließen die Verbindung nicht mehr aktiv vor der 413-Antwort.

### Regression-Schutz

- neuer Laufzeittest für `renderFrame()` mit aktivem Übergang
- Playback-Loop-Test ohne blockierende Media-Promises
- Playhead-Pointer-/Hit-Area-Test
- SmartCut-Cleanup-/99-%-Test
- echter Chromium-End-to-End-Lauf mit Video, Marker-Drag, Musik, SmartCut, Szenenanalyse, Übergängen und anschließender Wiedergabe

## 0.3.0 – Full Editor Restore

### Wiederhergestellt

- komplette große BeatCut-Editoroberfläche
- Mehrspur-Timeline
- Originalton-Zeilen
- Text / Video-FX / Übergänge / Audio-FX / Musik
- SmartCut inklusive Stilen, Beatmatching und Szenenanalyse
- BPM-/Beat-/Waveform-/Pitch-Analyse
- Drag & Drop
- Mehrfach-/Spurauswahl
- Split / Trim / Copy-to-Playhead / Delete
- Undo / Redo
- Auflösung und Social-Limits
- Browserprojektspeicher und `.beatcut`

### Export

- vollständige Canvas-Komposition bleibt Exportbasis
- WebCodecs-H.264 mit framegenauer Projektzeit für Chrome/Edge
- serverseitiges natives FFmpeg für MP4 statt FFmpeg.wasm
- Firefox/no-WebCodecs: MediaRecorder-WebM → nativer Server-MP4-Fallback
- CFR, H.264, AAC, YUV420P, SAR 1:1, Fast Start
- MP4-Startzeit/Dauer korrigiert (`-avoid_negative_ts disabled`, Edit List)
- Social-60-Test: 59,900 s / 1797 Frames bei 30 FPS

### Robustheit

- ungültige Video-/Bilddateien werden beim Import abgelehnt
- ungültige Musik wird sauber zurückgerollt
- strikte Media-Metadata-/Seek-Prüfung beim deterministischen Export
- `.beatcut` CRC-, Pfad-, Größen-, Eintrags- und JSON-Limits
- Legacy-Musikmigration korrigiert
- verwaiste temporäre Server-Transfers werden periodisch entfernt
- oversized Upload liefert zuverlässig 413 statt sporadischem Netzwerkabbruch

### Sicherheit

- JSZip lokal gebündelt
- externe FFmpeg.wasm/unpkg-Runtime-Abhängigkeit deaktiviert
- CSP erlaubt keine externen Scripts
- Path-Traversal, Dateinamen, IDs und API-Daten validiert
- FFmpeg ohne Shell mit Timeout/Abbruch und begrenzten Logs
