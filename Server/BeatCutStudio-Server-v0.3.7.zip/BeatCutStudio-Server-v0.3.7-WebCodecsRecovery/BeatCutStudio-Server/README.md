# BeatCut Studio Server – Full Editor v0.3.7

BeatCut Studio ist wieder die **vollständige große Editor-Version** mit Mehrspur-Timeline, SmartCut, BPM/Beats, Originalton, Musik, Texten, Video-/Audioeffekten, Übergängen, Undo/Redo, Drag & Drop und Projektdateien. Die Serverfassung ersetzt nicht den Editor, sondern nur die Teile, die im reinen Browser unzuverlässig waren – vor allem den finalen MP4-Mux-/Normalisierungsschritt.

## Neu in v0.3.7 – robuster WebCodecs-Export

Der MP4-Export behandelt jetzt Chromium/Brave-Fehler wie **„Codec reclaimed due to inactivity“** automatisch. Jeder erzeugte Frame wird vor dem nächsten potentiell langen Video-Seek vollständig geflusht. Wird der Browsercodec trotzdem freigegeben, startet BeatCut den Encoder neu, erzwingt einen Keyframe und kann auf einen Softwarecodec wechseln. Scheitert auch der Wiederanlauf mehrfach, wechselt BeatCut automatisch auf den vorhandenen MediaRecorder→Server-FFmpeg-Kompatibilitätsweg, statt den Export abzubrechen.

Der Server akzeptiert den dadurch möglichen Annex-B-H.264-Strom mit wiederholten SPS/PPS/IDR-Sequenzen und normalisiert ihn weiterhin zu H.264/AAC-MP4 mit konstanter Framerate.


## Neu in v0.3.6 – frei gewichtete SmartCut-Szenenanalyse

SmartCut besitzt im Dialog jetzt den aufklappbaren Bereich **„Szenenanalyse & Gewichtung“**. Die Stilprofile laden passende Startwerte, alle Werte können anschließend frei verändert werden.

Regler:

- **Bewegung** – positive Werte bevorzugen bewegte Szenen, negative ruhige Szenen.
- **Kontrast** – positive Werte bevorzugen kontrastreiche, negative weichere Szenen.
- **Sättigung** – positive Werte bevorzugen kräftige Farben, negative entsättigte Bilder.
- **Schärfe / Details** – positive Werte bevorzugen detailreiche/scharfe Frames, negative weichere Bilder.
- **Helligkeit** – positive Werte bevorzugen helle, negative dunklere Szenen.
- **Farbwärme** – positive Werte bevorzugen warme, negative kühle Farbstimmungen.
- **Analysegenauigkeit** – bestimmt die Dichte der Grob- und Feinanalyse.

Die Skala der Merkmalsregler reicht von **−100 bis +100**. `0` ignoriert das jeweilige Merkmal. Über **„Stilwerte laden“** wird das Profil des aktuell gewählten SmartCut-Stils geladen; **„Keine Gewichtung“** setzt alle Merkmalsgewichte auf 0.

Die Analyse arbeitet jetzt zweistufig: Zuerst wird das gesamte Video grob abgetastet. Anschließend werden die interessantesten Zeitbereiche mit zusätzlichen Frames feiner untersucht. Rohwerte werden im Projekt gespeichert und beim SmartCut mit den aktuell eingestellten Gewichten neu bewertet. Dadurch können dieselben analysierten Videos mit unterschiedlichen Gewichtungen andere Quellbereiche liefern, ohne zwingend erneut analysiert zu werden. Eine höhere Analysegenauigkeit löst bei Bedarf eine dichtere Neuanalyse aus.






## Korrekturen in v0.3.5

### Große `.beatcut`-Projektdateien

Der Projektdatei-Download wird nicht mehr vollständig im Browser mit `JSZip.generateAsync({ type: "blob" })` aufgebaut. Bei mehreren langen Videodateien konnte der Browser beim abschließenden Gesamt-Blob an Speicher-/Blob-Grenzen scheitern (`can't construct the Blob`).

Die neue Pipeline arbeitet serverseitig und streaming-basiert:

1. `project.json` wird an den lokalen BeatCut-Server übergeben.
2. Medien und Musik werden nacheinander als Dateien gestreamt; es wird kein Gesamt-Blob im Browser erzeugt.
3. Der Server schreibt ein ZIP im STORE-Verfahren direkt auf die Festplatte. Bereits komprimierte MP4/MP3/JPEG-Dateien werden nicht erneut rechenintensiv komprimiert.
4. Der Browser lädt die fertige `.beatcut`-Datei anschließend direkt vom Server herunter.

Der Server unterstützt dabei auch ZIP64 für große Archive. Projektpfade, IDs, Dateinamen und Größen werden validiert. Unvollständige Uploads können nicht finalisiert werden. Temporäre Projektpakete werden automatisch bereinigt.

**Wichtig:** Für den Projektdatei-Download muss BeatCut über den Server (`http://127.0.0.1:5000` bzw. den späteren Webserver) geöffnet sein.

## Korrekturen in v0.3.4

- **Erste Vorschau / Schwarzframes:** Videoframes werden für die interaktive Vorschau bevorzugt über `requestVideoFrameCallback` erst nach tatsächlicher Dekodierung übernommen. Während eines Decoder-Seeks bleibt der letzte vollständig zusammengesetzte Vorschauframe sichtbar, statt einen schwarzen Zwischenframe durch Effekte/Übergänge zu schicken.
- **Effekte beim ersten Durchlauf:** Der Fallback hält die bereits vollständig compositete Vorschau fest; Effekte, Übergänge und Texte werden auf diesen gehaltenen Frame nicht ein zweites Mal angewendet. Dadurch entstehen beim Decoderwechsel keine doppelten oder halb initialisierten Effektbilder.
- **Audioexport:** Der normale Projekt-Audiomix wird mit `OfflineAudioContext` deterministisch auf 48 kHz Stereo gerendert und als PCM-WAV an den Server übergeben. Die Tab-Stummschaltung beeinflusst diesen Pfad nicht.
- **Audio-Fallback:** Speed-/Tape-FX, sehr lange Projekte (> 15 min) oder extrem große Audiomengen verwenden weiterhin den vorhandenen Echtzeit-Audiopfad, weil diese Effekte nicht 1:1 durch den einfachen Offline-Bufferpfad ersetzt werden können.
- **Schnellere `.beatcut`-Dateien:** Medien werden nicht mehr sinnlos erneut mit DEFLATE komprimiert. MP4/MP3/JPEG/PNG sind bereits komprimiert; das Archiv verwendet `STORE` + `streamFiles`, wodurch die Projekterstellung deutlich weniger CPU benötigt.

## Vorschau-Performance in v0.3.3

- Vorschau-Canvas und Medien-Synchronisierung werden während der Wiedergabe auf **30 FPS** begrenzt; der Playhead bleibt weiterhin an die Display-Animation gekoppelt und wirkt dadurch flüssig.
- Laufende Videos werden nicht mehr bei kleinen Zeitabweichungen ständig neu gesucht. Erst ab deutlicher Drift erfolgt eine harte Korrektur.
- Während der Wiedergabe wird kein redundanter Video-Frame mehr in einen zweiten Cache-Canvas kopiert.
- Audioquellzeiten ohne Speed-/Tape-FX werden direkt berechnet statt bei jedem Frame vom Clipanfang in 25-ms-Schritten integriert zu werden.
- Der 2D-Canvas verwendet, sofern vom Browser unterstützt, den latenzarmen `desynchronized`-Modus.
- Diese Änderungen betreffen nur die **Vorschau**; der framegenaue MP4-Export und seine Ausgabeauflösung bleiben unverändert.
## Korrekturen in v0.3.2

- **SmartCut-TDZ behoben:** In `renderFrame()` verwendete der Übergangsfilter versehentlich die Schleifenvariable `t`, bevor diese initialisiert war. Sobald SmartCut Übergänge erzeugt hatte, brach die Finalisierung mit `can't access lexical declaration 't' before initialization` ab.
- **Video läuft wieder sichtbar:** Derselbe `renderFrame()`-Fehler beendete den Animationsloop nach dem Start. Audio konnte bereits laufen, während Canvas/Videobild stehenblieben. Der Übergangsfilter verwendet jetzt ausschließlich sein Callback-Element und rendert aktive Übergänge ohne TDZ-Fehler.
- **Playhead/Marker repariert:** Weil `setProjectTime()` vor `updatePlayhead()` in `renderFrame()` abstürzte, reagierte der Marker bei Projekten mit Übergängen nicht. Nach der Korrektur sind Klick, Direkt-Drag und Playback-Follow wieder funktionsfähig.
- **Nicht-blockierende Medienwiedergabe beibehalten:** Canvas und Playhead warten nicht auf `HTMLMediaElement.play()`-Promises. Die vergrößerte Playhead-Hit-Area bleibt erhalten.
- **SmartCut-Cleanup:** `try/catch/finally`, Analyse-Timeouts und garantierter Busy-/Task-Cleanup bleiben aktiv; 100 % wird erst nach erfolgreichem Abschluss angezeigt.
- **Oversized Upload:** Ein bekannter zu großer Upload liefert zuverlässig HTTP 413, ohne die Verbindung aktiv so zu schließen, dass Browser/undici nur `fetch failed` sehen.

## Architektur

- **Browser:** vollständiger BeatCut-Editor und Vorschau-Komposition
- **Node.js-Server:** lokale HTTP/API-Schicht, sichere Render-Uploads, Projekt-/Medien-API
- **natives FFmpeg/FFprobe:** finale H.264/AAC-MP4-Erzeugung
- **SQLite (Node 22 `node:sqlite`):** serverseitige Metadaten/Jobs
- **JSZip lokal gebündelt:** `.beatcut`-Projektdateien benötigen kein externes Script-CDN

Die Anwendung läuft lokal standardmäßig unter:

`http://127.0.0.1:5000`

## Lokal unter Windows starten

### Voraussetzungen

1. Node.js **22.5 oder neuer**
2. Eine vollständige FFmpeg-Version mit `ffmpeg.exe` und `ffprobe.exe`

Lege FFmpeg bevorzugt hier ab:

```text
tools\ffmpeg\ffmpeg.exe
tools\ffmpeg\ffprobe.exe
```

Ein **Static Build** ist unter Windows am unkompliziertesten. Bei einem Shared Build müssen zusätzlich sämtliche zugehörigen FFmpeg-DLLs im selben Verzeichnis beziehungsweise im Suchpfad vorhanden sein.

Danach:

```text
start-local.bat
```

Der Browser wird automatisch geöffnet. Nicht `frontend/index.html` direkt per Doppelklick öffnen – die Anwendung soll über den lokalen BeatCut-Server laufen.

## Wiederhergestellter Funktionsumfang

### Medien und Timeline

- Bilder und Videos importieren
- Musik importieren
- Medienbrowser
- Drag & Drop in die Timeline
- Doppelklick zum Einfügen am Playhead
- mehrere Videospuren
- separate Originalton-Zeilen
- Textspur
- Video-FX-Spur
- Übergangsspur
- Audio-FX-Spur
- Musikspur
- Timeline-Zoom
- Playhead-Verschiebung
- Track-Auswahl über Spurname
- Mehrfachauswahl
- Clips verschieben
- links/rechts trimmen
- teilen
- löschen
- Auswahl an Playhead kopieren
- Undo/Redo

### Vorschau und Transport

- Projektvorschau auf Canvas
- Anfang/Ende
- vorheriger/nächster Schnitt
- vorheriger/nächster Beat
- Frame vor/zurück
- Play/Pause
- direkte Textverschiebung in der Vorschau

### SmartCut

- Balanced
- Dynamic
- Cinematic
- Energetic
- Smooth
- Travel
- Minimal
- Dreamy
- Glitch / Tech
- Dramatic
- Beats pro Clip
- BPM
- Beatmatching
- Szenenanalyse
- automatische Effekte
- automatische Übergänge
- Auswahl erlaubter Effekte/Übergänge
- Regenerierung automatisch erzeugter Clips

### BPM / Musik / Audio

- lokale BPM-/Beat-Analyse im Browser
- Beatpositionen und Beatphase
- Waveform
- Pitch-Kurve
- Musiksegmente mit Start, Quellstart, Dauer, Lautstärke und Fades
- Originalton pro Videoclip
- Originalton laut/leise/stumm/deaktiviert
- Originalton-Fade-In/Fade-Out
- Audio-FX auf Musik, Track oder einzelne Originalton-Clips

Audio-FX:

- Ton absenken
- Stumm
- Lautstärkepuls
- 1,5× / 2× schneller
- 0,75× / 0,5× langsamer
- Tape Stop
- Tape Start

### Videoeffekte

Unter anderem:

- Flash
- Glitch
- Strobe
- Vignette
- Film Grain
- Cinematic
- Neon
- Dream
- Shake
- Hue Shift
- Zoom Punch
- Black & White
- Warm / Cold
- Invert
- Blur Pulse
- RGB Shift
- Scanlines
- Exposure Pulse
- Soft Glow
- Letterbox
- Pixelate
- Color Wash

### Übergänge

Unter anderem:

- Fade / Black / White / Flash
- Zoom / Spin / Blur / Glitch
- Slide Left/Right/Up/Down
- Wipe Left/Right/Up/Down
- Whip Left/Right
- Iris
- Bars

### Text

- Inhalt
- Start/Dauer
- Schriftart
- Gewicht
- kursiv
- Größe
- Skalierung
- X/Y
- Farbe
- Deckkraft
- Rotation
- Umrandung, Farbe und Stärke

### Projekt

- frei wählbare Auflösung
- Presets 16:9, 9:16, 1:1, 4:5
- Zeitlimits 15/30/60/90/180 s oder manuell
- Limit-Linie in der Timeline
- Browserprojekt speichern/laden
- `.beatcut`-Projektdatei herunterladen/öffnen
- Legacy-Projekte ohne `musicSegments` werden korrekt migriert

## MP4-Export

### Chrome / Edge – bevorzugter Weg

Wenn WebCodecs verfügbar ist:

1. BeatCut rendert **jeden Projektframe anhand der Timeline-Zeit**.
2. Canvas-Komposition enthält die sichtbaren Texte, Effekte und Übergänge.
3. WebCodecs erzeugt einen H.264-Videostream mit festen Zeitstempeln.
4. Der normale BeatCut-Audiomix wird offline auf 48 kHz Stereo gerendert und als WAV vorbereitet; nur Speed-/Tape-FX bzw. sehr große Projekte verwenden den Echtzeit-Fallback.
5. Beide Streams werden zum lokalen Server übertragen.
6. Natives FFmpeg erzeugt daraus ein CFR-H.264/AAC-MP4.

Dadurch ist die Videozeit nicht mehr davon abhängig, wie schnell der Browser tatsächlich rendert.

### Firefox / Browser ohne WebCodecs

BeatCut verwendet den vollständigen Canvas-/Audio-Recorder als Kompatibilitätsweg und lässt anschließend **natives Server-FFmpeg** die WebM-Aufnahme als H.264/AAC-MP4 normalisieren. Der gesamte Editor bleibt nutzbar; bei sehr langsamen Rechnern ist dieser Echtzeit-Fallback jedoch naturgemäß weniger framegenau als der WebCodecs-Weg.

### 60-Sekunden-Social-Video

Für die 60-s-Grenze wird auf eine sichere framegenaue Dauer unterhalb der Plattformgrenze gerendert. Bei 30 FPS sind das:

- 1797 Frames
- 59,900 Sekunden

Der Server setzt unter anderem:

- H.264
- AAC 48 kHz Stereo
- YUV420P
- CFR
- SAR 1:1
- Video-Timescale 90000
- Startzeit 0
- MP4 Fast Start
- exakte Frame-/Dauerbegrenzung

## Sicherheits- und Robustheitsmaßnahmen

- Server bindet standardmäßig nur an `127.0.0.1`
- öffentliche Bindung erfordert explizites `BEATCUT_ALLOW_REMOTE=1`
- das ist **keine Authentifizierung**; für einen öffentlichen Server sind Reverse Proxy, TLS und Login erforderlich
- Pfad-Traversal-Schutz
- Upload-/JSON-Größenlimits
- Dateiendungs- und Medienvalidierung
- FFprobe prüft echte Medieninhalte
- sichere Prozessaufrufe ohne Shell
- FFmpeg-/FFprobe-Timeouts
- begrenzte Prozesslogs
- Range-/HEAD-Unterstützung
- temporäre Renderinputs werden nach Jobs entfernt
- verwaiste Transferdateien werden beim Start und periodisch bereinigt
- `.beatcut`-Archive werden mit CRC-Prüfung, Pfad-, Eintrags-, JSON- und Größenlimits geöffnet
- ungültige Bilder/Videos/Musik werden beim Laden abgelehnt statt mit erfundenen Metadaten weiterverarbeitet
- keine externen Runtime-Skripte; JSZip liegt lokal

## Netzwerkabhängigkeiten

Der Editor benötigt für seine Kernfunktionen und den MP4-Export keine externen JavaScript-CDNs mehr. Google Fonts werden weiterhin optional extern geladen. Sind sie nicht erreichbar, arbeitet BeatCut mit lokal verfügbaren Fallback-Schriften weiter; das kann nur die Darstellung bestimmter Schriftarten verändern.

## Testen

Im Projektordner:

```text
cd backend
npm test
```

Es gibt keine npm-Laufzeitabhängigkeiten, die vorher installiert werden müssen. Das Backend verwendet Node-Bordmittel einschließlich `node:sqlite`.

## Wichtige verbleibende technische Grenze

Der visuelle Chrome/Edge-MP4-Pfad ist framegenau. Der normale Audiomix (Musik, Originalton, Lautstärke und Fades) wird jetzt offline mit `OfflineAudioContext` erzeugt und ist damit nicht von der Tab-Stummschaltung abhängig. Speed-/Tape-FX sowie sehr große oder sehr lange Projekte verwenden weiterhin den Echtzeit-Audio-Fallback.

`.beatcut`-Dateien werden weiterhin vollständig im Browser als ZIP-Blob zusammengesetzt. Durch `STORE` statt DEFLATE ist dieser Schritt deutlich schneller; bei Projekten im Multi-GB-Bereich bleiben jedoch RAM-Bedarf und Schreibdauer des Browsers eine technische Grenze.

Für einen späteren öffentlichen VPS sollte außerdem noch Benutzerverwaltung/Authentifizierung, Quotas, Upload-Storage und eine persistente Render-Queue ergänzt werden.
