# BeatCut Studio v0.3.7 – QA-Bericht

## Ergebnis

Die gemeldeten Fehler wurden bis auf den gemeinsamen Root Cause zurückverfolgt und anschließend mit statischen, Laufzeit-, HTTP-, Render- und echten Chromium-Regressionsprüfungen verifiziert.

**Automatisierte Node-Suite v0.3.7:** 32/32 bestanden, 0 Fehler, 0 übersprungen.  
**Zusätzliche FFmpeg-Integration:** concatenierte Annex-B-H.264-Sitzungen nach Encoder-Neustarts werden vollständig mit 30 FPS eingelesen.  
**Chromium-E2E der zugrunde liegenden v0.3.6:** Video-Wiedergabe, Playhead, Musik und SmartCut waren erfolgreich; der neue Reclaim-Fall wird in v0.3.7 durch gezielte WebCodecs-/FFmpeg-Regressionstests abgedeckt.



## Zusätzliche QA in v0.3.7

- WebCodecs-Reclaim-Erkennung für `reclaimed`, `inactivity` und geschlossene Encoderzustände.
- Regressionstest: WebCodecs-Export besitzt automatischen Encoder-Neustart, Software-Fallback und MediaRecorder-Kompatibilitätsfallback.
- FFmpeg-Integrationstest: fünf separat erzeugte Annex-B-H.264-Einzelsitzungen werden hintereinandergehängt und als 5-Frame-CFR-MP4 korrekt gelesen.
- Bestehende Upload-, Projekt-, SmartCut-, Preview-, Audio- und Server-Render-Regressionen bleiben grün.


## Zusätzliche QA in v0.3.6

- DOM-Prüfung aller neuen Analyse-Schieberegler ohne doppelte IDs oder fehlende `$()`-Ziele.
- Laufzeittest für vorzeichenbehaftete Gewichtungen: `+100 Bewegung` bevorzugt hohe Bewegung, `−100 Bewegung` bevorzugt niedrige Bewegung.
- Test für vollständig neutrale Gewichtung (alle Regler 0 → neutraler Score 0,5).
- Statische Prüfung der zweistufigen Grob-/Feinanalyse, Schärfemetrik, Bewegungsnormalisierung und dynamischen Quellfensterbewertung.
- SmartCut-Einstellungen persistieren Analysegewichte/Genauigkeit im Projektformat v22 und alte Projekte fallen auf das jeweilige Stilprofil zurück.


## Zusätzliche QA in v0.3.5 und v0.3.4

### Projektpaket-Regressionen v0.3.5

- API-Test mit drei getrennten Medien in einer `.beatcut`-Datei.
- Finalisierung wird abgelehnt, solange erwartete Medien fehlen.
- Falsche Uploadgrößen werden abgelehnt.
- Unsichere Medien-IDs und Nullgrößen werden abgelehnt.
- Der serverseitige STORE-ZIP-Writer wird mit dem tatsächlich gebündelten JSZip inklusive `checkCRC32:true` wieder eingelesen.
- ZIP-Pfad-Traversal (`../...`) wird vom Writer abgelehnt.
- Drei 16-MiB-Einträge werden streaming-basiert geschrieben, ohne einen aggregierten Browser-Blob zu erzeugen.


1. **Preview-Schwarzframe:** Runtime-Regressionsprüfung simuliert einen aktiven Videoclip, dessen Decoder beim ersten Frame noch nicht bereit ist. Erwartung: Last-Good-Preview wird genau einmal gezeichnet; Effekte/Übergänge werden auf diesem bereits compositeten Frame nicht erneut ausgeführt.
2. **Dekodierter Framecache:** Quellcode-/Runtime-Prüfung auf `requestVideoFrameCallback`, Seeking-Guard und Zeitnähe des Cacheframes.
3. **Offline-Audio:** WAV-Helfer erzeugt gültiges PCM16-Stereo-WAV; Primärpfad nutzt `OfflineAudioContext`.
4. **Native WAV-Integration:** echter WAV-Input wird über die Server-Renderroute mit FFmpeg zu AAC im MP4 gemuxt.
5. **Tab-Mute-Unabhängigkeit:** Der normale Exportpfad hängt nicht am hörbaren Tab-Ausgang, sondern an einem Offline-Audiographen.
6. **Projektdatei-Performance:** statische Prüfung auf `compression: "STORE"`, `streamFiles: true` und Entfernung der DEFLATE-Rekompression für Medien.
7. **Exportregression:** deterministischer Video-/Serverpfad, CFR, 59,900-s-Socialgrenze und bestehende Sicherheits-/Lifecycle-Tests bleiben unverändert grün.

Ein echter aktueller Chromium-GUI-E2E-Lauf konnte in dieser Ausführungsumgebung nicht ausgeführt werden, weil eine verwaltete Chromium-Richtlinie lokale HTTP-Ziele (`127.0.0.1` und Container-IP) blockiert. Dieser Infrastrukturblock wurde nicht als Anwendungserfolg gewertet. Die betroffenen Preview-/Audio-Pfade sind deshalb zusätzlich durch gezielte Runtime-/Integrationstests abgedeckt.

## Vorschau-Performance v0.3.3

1. **Zu viele Voll-Renderzyklen:** Auf 60-/120-Hz-Monitoren wurde die komplette Canvas-Komposition entsprechend oft ausgeführt. Vorschau-Rendering und Medien-Sync sind jetzt auf 30 FPS begrenzt; der Playhead bleibt ungedrosselt.
2. **Seek-Thrashing:** Kleine Videoabweichungen konnten wiederholte `currentTime`-Seeks auslösen und den Decoder ständig neu starten. Während Playback wird erst ab 700 ms Drift hart nachgeführt.
3. **Redundantes Frame-Caching:** Jeder aktive Videoframe wurde vor dem eigentlichen Canvas-Draw zusätzlich in einen Cache-Canvas kopiert. Während Playback entfällt diese Kopie; der Cache wird nur noch für Pause/Seek benötigt.
4. **Audio-Berechnung wuchs mit der Projektzeit:** `integrateRate()` lief bei jeder Synchronisation vom Clipanfang in 25-ms-Schritten. Ohne Speed-/Tape-FX wird jetzt direkt `end-start` verwendet.
5. **Canvas-Latenz:** Der sichtbare 2D-Kontext fordert nun den optionalen `desynchronized`-Modus an.

Die aktuelle Ausführungsumgebung blockiert lokale HTTP-Seiten im verwalteten Chromium per Organisationsrichtlinie. Deshalb konnte für v0.3.3 kein neuer GUI-E2E-Lauf gegen `127.0.0.1` gestartet werden. Die Node-/VM-Regressionsprüfungen decken Preview-Taktung, nicht-blockierende Medienpromises, Playhead-Fortschritt und den unveränderten Exportpfad ab.
## Gefundene und behobene Probleme

1. **Temporal-Dead-Zone im Übergangsrenderer:** `renderFrame()` verwendete im `transitions.filter(...)` die Variable `t`, obwohl `t` erst danach als `for ... of`-Variable initialisiert wurde. Korrigiert auf das Filterelement `x` und eindeutige Schleifenvariable `transition`.
2. **SmartCut-Abbruch:** SmartCut erzeugte Übergänge, rief bei der Finalisierung `setProjectTime(0)` → `renderFrame(0)` auf und lief dadurch in genau den TDZ-Fehler. Nach dem Fix schließt SmartCut sauber und erzeugt im Browsertest 6 Clips + 5 Übergänge.
3. **Video steht, Ton läuft:** Audio wurde bereits gestartet; anschließend warf `renderFrame()` im Wiedergabeloop den TDZ-Fehler. Der nächste `requestAnimationFrame` wurde nicht mehr geplant. Nach dem Fix läuft Canvas/Video weiter.
4. **Marker bewegt sich nicht:** `setProjectTime()` ruft `renderFrame()` vor `updatePlayhead()` auf. Der TDZ-Fehler verhinderte deshalb auch Klick-/Drag-Updates des Markers. Nach dem Fix funktioniert Direkt-Drag wieder.
5. **Oversized Upload / Netzwerkfehler:** `Connection: close` bei einer frühen 413-Antwort konnte `fetch failed` statt der HTTP-Antwort verursachen. Der Request-Body wird stromweise verworfen, ohne die Verbindung aktiv vorzeitig zu schließen.

## Durchgeführte Prüfungen

- Syntax des kompletten Frontend-Moduls via `node --check`
- Syntax/Startpfade des Node-Backends
- DOM-ID-Konsistenz und `$()`-Referenzen
- vollständige Funktionsmarker für SmartCut, Timeline, Originalton, Musik, Text, Video-FX, Übergänge, Audio-FX, Undo/Redo, Projektdateien und Serverexport
- Regressionstest: `renderFrame()` mit aktivem Übergang darf keine TDZ auslösen und ruft den Übergangsrenderer exakt auf
- Regressionstest: Playback-Loop plant das nächste `requestAnimationFrame` auch bei nie auflösenden Media-Promises
- Regressionstest: Playhead besitzt dedizierten Pointer-Handler und vergrößerte Hit-Area
- Regressionstest: SmartCut besitzt Cleanup über `finally`, Busy-Reset und 99-%-Grenze bis zur Finalisierung
- realer HTTP-Upload, FFprobe, Thumbnail, Range/HEAD, ungültige Eingaben und Path-Traversal
- Größenlimits für Upload und JSON
- Projektvalidierung positiv/negativ
- fehlendes FFmpeg/FFprobe, öffentliche Bindung, belegter Port
- Renderqueue, Cancel und temporärer Input-Cleanup
- H.264/AAC/CFR/SAR/Startzeit-Muxing
- Social-60: 59,900 s / 1797 Frames bei 30 FPS
- Chromium: Testvideo geladen und abgespielt; Playhead 0,00 → ca. 0,94 s
- Chromium: Canvas-Pixelstichprobe änderte sich während der Videowiedergabe
- Chromium: Playhead per Maus auf ca. 1,42 s gezogen
- Chromium: Musik analysiert, SmartCut mit Szenenanalyse/Auto-Transitions ausgeführt
- Chromium: SmartCut-Ergebnis 6 Clips / 5 Übergänge / Status `SmartCut fertig`
- Chromium: Wiedergabe nach SmartCut lief weiter (ca. 0,91 s nach 0,9 s Laufzeit)
- Chromium: 0 Runtime-Exceptions, 0 SmartCut-Fehlerdialoge

## Sicherheitsprüfung

- keine Verwendung von `eval()` oder `new Function()` im Anwendungscode
- FFmpeg/FFprobe werden mit Argumentarrays und `shell:false` gestartet
- Uploadnamen, IDs, statische Pfade und Projektwerte werden validiert
- Path-Traversal-Prüfungen bleiben aktiv
- interne Dateipfade werden nicht als rohe API-Fehler ausgegeben
- Größenlimits und temporäre Dateibereinigung bleiben aktiv

## Verbleibende technische Einschränkungen

- Der visuelle Chrome/Edge-MP4-Pfad ist framegenau; der normale Audiomix wird offline als WAV erzeugt. Speed-/Tape-FX sowie Ressourcenlimitfälle verwenden weiterhin den Echtzeit-Fallback.
- Browser ohne WebCodecs verwenden den MediaRecorder-Kompatibilitätsweg.
- Google Fonts sind optional extern; offline greifen Fallback-Fonts.
- Vor öffentlicher Internetbereitstellung sind weiterhin Authentifizierung, TLS/Reverse-Proxy, Quotas und Storage-Regeln erforderlich.

Innerhalb der geprüften lokalen Editor-, Upload- und Renderpfade sind für v0.3.2 keine weiteren reproduzierbaren Fehler bekannt.

---

## Frühere v0.3.0-QA-Befunde



1. **Abgespeckte Serveroberfläche:** Der frühere Server-Prototyp enthielt nicht mehr den vollständigen BeatCut-Funktionsumfang. Die große Editorbasis wurde wiederhergestellt und mit der Server-Renderbridge verbunden.
2. **Browser-Echtzeitvideo / falsche MP4-Zeitbasis:** Primärer Chrome/Edge-Export rendert nun exakt einen Projektframe je Framezeit und lässt den Server CFR-MP4 finalisieren.
3. **MP4-Startzeit durch AAC/`make_zero`:** `-avoid_negative_ts make_zero` verschob Audio/Video. Serverexport verwendet Edit List und unveränderte negative-TS-Behandlung; Startzeit und Dauer werden getestet.
4. **60-s-Plattformgrenze:** Social-60 wird bei 30 FPS als 1797 Frames = 59,900 s ausgegeben.
5. **FFmpeg.wasm/CDN:** aktive MP4-Pfade verwenden ausschließlich natives Server-FFmpeg. CSP erlaubt keine unpkg-Scripts mehr.
6. **Ungültige Medien:** Videos wurden früher bei Metadatenfehlern still als 1 s angenommen. Bilder/Videos/Musik werden nun beim Import validiert und bei Decoderfehlern abgelehnt.
7. **Stale Frames beim Export:** Video-Seeks konnten früher nach Timeout still weiterlaufen. Deterministischer Export bricht bei Metadata-/Seek-Timeout oder Decoderfehler mit verständlicher Meldung ab.
8. **Manipulierte `.beatcut`-Archive:** CRC-Prüfung, Pfadvalidierung, Eintragszahl, JSON-Größe und Größenlimits ergänzt; Medien werden vor dem destruktiven Projektwechsel geprüft.
9. **Legacy-Projekt mit Musik:** Fehlende alte `musicSegments`-Eigenschaft überschreibt nicht mehr das beim Musikladen erzeugte Standardsegment.
10. **Übergröße-Upload-Flakiness:** Bei bekannt zu großer `Content-Length` wurde die Verbindung zu früh geschlossen. Body wird nun stromweise verworfen und HTTP 413 zuverlässig beantwortet.
11. **Temporäre Renderdateien:** Neben Cleanup bei Jobende/Startup gibt es periodische Bereinigung alter Transferartefakte.
12. **Audio-Autoplay-Risiko:** Der AudioContext für den primären MP4-Export wird früh im Exportvorgang aktiviert und später für den Audiomix wiederverwendet.
13. **FFprobe Shared-Build/DLL-Fehler:** Windows-Code 0xC0000135 wird diagnostiziert; Server unterscheidet fehlendes Tool von nicht lauffähigem Build.
14. **Interne Pfade in Fehlern:** Medien-/Toolfehler werden nach außen sanitisiert.
15. **Path Traversal / unsichere Dateien:** Routen, IDs, Uploadnamen und statische Dateiauflösung sind begrenzt/validiert.

## Automatisierte Prüfungen

Die Suite umfasst derzeit 24 Top-Level-Integration-/Static-/Lifecycle-/Runtime-Tests mit vielen Einzelassertionen:

- vollständige Frontend-Modulsyntax via `node --check`
- keine doppelten statischen DOM-IDs
- `$()`-Referenzen besitzen mögliche DOM-Ziele
- vollständige Funktionsmarker für SmartCut, Originalton, Text, FX, Übergänge, Audio-FX, Undo/Redo, Kopieren und Serverexport
- keine unpkg-Runtime-Abhängigkeit
- lokale JSZip-Datei vorhanden
- Projektvalidierung positiv/negativ
- Upload echter Bilder
- Upload echter MP4-Datei mit Audio
- FFprobe-Metadaten
- Thumbnailerzeugung
- Fake-MP4-Ablehnung
- Dateiendungsprüfung
- manipulierte Dateinamen
- Path Traversal
- Range und HEAD
- fehlerhafte URL-Kodierung
- ungültiges JSON
- zu großes JSON
- zu große Uploads
- Projekt-Save/Load-API
- fehlendes FFmpeg/FFprobe
- öffentliche Bindung ohne Opt-in
- belegter Port
- Renderqueue und Cancel
- temporärer Input-Cleanup
- precomposed H.264 + Opus → H.264/AAC MP4
- WebM/Opus-Kompatibilitätsweg → H.264/AAC MP4
- Startzeit 0
- exakte Dauer 1,000 s im Kurztest
- CFR 30 FPS
- SAR 1:1
- AAC 48 kHz Stereo
- 59,900-s-Socialtest
- 1797 Frames bei 30 FPS

Nach der letzten Reparatur wurde die komplette Suite **dreimal hintereinander erfolgreich (26/26, 0 Fehler)** ausgeführt. Die finale Staging-Version und die gepackte ZIP werden zusätzlich gegen dieselbe Suite geprüft.

## Manuelle/GUI-Prüfung

Ein echter Chromium-Headless-DOM-Lauf war in der bereitgestellten Linux-Containerumgebung selbst für triviale URLs nicht zuverlässig möglich (Chromium/DBus/Zygote-Umgebungsproblem). Dieses Infrastrukturproblem wurde nicht als Anwendungstest gewertet.

Stattdessen wurden Frontend-Syntax/DOM-Konsistenz statisch und sämtliche Server-/Upload-/FFmpeg-Renderpfade mit realen HTTP- und Medien-Integrationstests geprüft.

## Verbleibende Einschränkungen

- Der **visuelle** Chrome/Edge-MP4-Pfad ist framegenau. Normaler Musik-/Originaltonmix samt Lautstärke/Fades wird offline als WAV erzeugt; Speed-/Tape-FX sowie sehr große/lange Projekte nutzen weiterhin den Echtzeit-Fallback.
- Browser ohne WebCodecs verwenden einen Echtzeit-MediaRecorder-Fallback. Auf sehr langsamen Rechnern kann dieser visuell weniger deterministisch sein als der WebCodecs-Weg.
- Google Fonts sind optional extern; offline werden Fallback-Fonts verwendet.
- Die lokale Standardinstallation besitzt absichtlich keine Benutzerkonten. Vor öffentlicher Internetbereitstellung müssen Authentifizierung, TLS/Reverse-Proxy, Quotas und Storage-Regeln ergänzt werden.

Innerhalb der automatisiert geprüften Pfade sind zum Zeitpunkt dieses Pakets keine weiteren bekannten Fehler oder Sicherheitsprobleme vorhanden.
